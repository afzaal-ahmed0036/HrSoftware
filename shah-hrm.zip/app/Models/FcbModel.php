<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class FcbModel extends Model
{
   protected $table = 'fcb';
}



<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>
 
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Visa Expiry List</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/Dashboard')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left me-1"></i>Go Back </a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->


 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3"  id="success-alert">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>


                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>

                                        <table class="table table-sm align-middle table-nowrap mb-0">
                                        <tbody><tr>
                                        <th class="col-md-1">S.No</th>
                                        <th class="col-md-4">Employee ID</th>
                                        <th class="col-md-1">Visa Expiry</th>
                                        <th class="col-md-1">Designation</th>
                                        <th class="col-md-1">Department</th>
                                        <th class="col-md-1">Detail</th>
                                        </tr>
                                        </tbody>
                                        <tbody>
                                        <?php $__currentLoopData = $visa_alert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                         <td ><?php echo e($key+1); ?></td>
                                         <td ><?php echo e($value->FirstName); ?> <?php echo e($value->MiddleName); ?> <?php echo e($value->LastName); ?></td>
                                         <td ><?php echo e(dateformatman($value->VisaExpiryDate)); ?></td>
                                         <td ><?php echo e($value->JobTitleName); ?></td>
                                         <td ><?php echo e($value->DepartmentName); ?></td>
                                         <td ><a    href="<?php echo e(URL('/EmployeeDetail/'.$value->EmployeeID)); ?>" target="_blank"   ><i class="mdi mdi-eye-outline align-middle me-1 font-size-20"></i></a> 


                                         <a  href="<?php echo e(URL('/ComposeEmail/'.$value->EmployeeID)); ?>" ><i class="bx bx-mail-send align-middle me-1 font-size-20"></i></a>
 

 
                                         

            
                                      

                                     </td>
                                         </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                         </tbody>
                                         </table> 
                                        
                                    </div>
                                    <!-- end card body -->


 
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->
   
 
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/visa_alert.blade.php ENDPATH**/ ?>
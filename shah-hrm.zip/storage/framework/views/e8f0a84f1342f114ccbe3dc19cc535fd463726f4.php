

<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Fleet Management</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->ss
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3"  id="success-alert">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

          

                      

    <div class="card">
        <div class="card-body">
            
            <h5>Vehicles</h5>

             <?php if(count($fleet_master)>0): ?>        
            <table class="table table-sm align-middle table-nowrap mb-0">
            <tbody><tr>
            <th scope="col">S.No</th>
            <th scope="col">Vehicle Model</th>
            <th scope="col">Owner Name</th>
            <th scope="col"></th>
            <th scope="col"></th>
           
            </tr>
            </tbody>
            <tbody>
            <?php $__currentLoopData = $fleet_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
             <td class="col-md-1"><?php echo e($key+1); ?></td>
             <td class="col-md-2"><?php echo e($value->VehicleModel); ?></td>
             <td class="col-md-10"><?php echo e($value->OwnerName); ?></td>
             <td class="col-md-1"><a href="<?php echo e(URL('/FleetEdit/'.$value->FleetMasterID)); ?>">Edit</a></td>
             <td class="col-md-1"><a href="<?php echo e(URL('/FleetDelete/'.$value->FleetMasterID)); ?>">Delete</a></td>
             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
             </tbody>
             </table>
             <?php else: ?>
               <p class=" text-danger">No data found</p>
             <?php endif; ?>   


        </div>
    </div>                   

                   <h4>Fleet Detail</h4>       
      
<div class="row">
    <div class="card">
         <div class="card-body"></div>
      
         <!-- enctype="multipart/form-data" -->
        <form action="<?php echo e(URL('/FleetDetailSave')); ?>" method="post">


         <?php echo e(csrf_field()); ?> 


      <div class="row">
 

 
         <div class="col-md-3">
      <div class="mb-3">
         <label for="basicpill-firstname-input">Vehicle*</label>
          <select name="FleetMasterID" id="FleetMasterID" class="form-select">
 
          <?php $__currentLoopData = $fleet_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value="<?php echo e($value->FleetMasterID); ?>" ><?php echo e($value->VehicleModel); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
      
       </select>
       </div>
        </div>

           
        
           


           
                 
                   <div class="col-md-2">
                            <div class="mb-3">
                              <label for="basicpill-firstname-input">Registration Start Date</label>
                                  <input name="RegistrationStartDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('RegistrationStartDate')); ?>" im-insert="false">
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                         </div>
                     </div> 
                       


                   <div class="col-md-2">
                            <div class="mb-3">
                              <label for="basicpill-firstname-input">Registration End  Date</label>
                                  <input name="RegistrationEndDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('RegistrationEndDate')); ?>" im-insert="false">
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                         </div>
                     </div> 
                       
           
   <div class="col-md-2">
                            <div class="mb-3">
                              <label for="basicpill-firstname-input">Insurance Start Date</label>
                                  <input name="InsuranceStartDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('InsuranceStartDate')); ?>" im-insert="false">
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                         </div>
                     </div> 


                       <div class="col-md-2">
                            <div class="mb-3">
                              <label for="basicpill-firstname-input">Insurance End Date</label>
                                  <input name="InsuranceEndDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('InsuranceEndDate')); ?>" im-insert="false">
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                         </div>
                     </div> 
 
 

  <div class="col-md-3">
<div class="mb-3">
<label for="basicpill-firstname-input">Insurance Company Name*</label>
<input type="text" class="form-control" name="InsuranceCompanyName" value="<?php echo e(old('InsuranceCompanyName')); ?> ">
</div>
</div>


<div class="col-md-2">
<div class="mb-3">
<label for="basicpill-firstname-input">Last Reading</label>
<input type="text" class="form-control" name="LastReading" value="<?php echo e(old('LastReading')); ?> ">
</div>
</div>


         <div class="col-md-2">
                            <div class="mb-3">
                              <label for="basicpill-firstname-input">Oil Change Date</label>
                                  <input name="OilChangeDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('OilChangeDate')); ?>" im-insert="false">
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                         </div>
                     </div> 


  

                             <div class="col-md-2">
                            <div class="mb-3">
                              <label for="basicpill-firstname-input">Oil Due Date</label>
                                  <input name="OilDueDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('OilDueDate')); ?>" im-insert="false">
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                         </div>
                     </div> 






 


      </div>
         
        

         <div><button type="submit" class="btn btn-success btn-sm float-right">Save / Update</button>
              <a href="<?php echo e(URL('/')); ?>" class="btn btn-secondary  btn-sm float-right">Cancel</a>
         </div>
          
         


        </form>              
                 

    </div>
</div>
     

         <div class="card">
        <div class="card-body">
            
            <h5>Vehicles</h5>

             <?php if(count($fleet_detail)>0): ?>        
            <table class="table table-sm align-middle table-nowrap mb-0">
            <tbody><tr>
            <th scope="col">S.No</th>
            <th scope="col">Reg Start Date</th>
            <th scope="col">Reg End Date</th>
            <th scope="col">Insurance By</th>
            <th scope="col">Insurance Start Date</th>
            <th scope="col">Insurance End Date</th>
            <th scope="col">Oil Reading</th>
            <th scope="col">Oil Change Date</th>
            <th scope="col">Oil Due Date</th>
            <th scope="col">Delete</th>
            
           
            </tr>
            </tbody>
            <tbody>
            <?php $__currentLoopData = $fleet_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
             <td class="col-md-1"><?php echo e($key+1); ?></td>
             <td class="col-md-2"><?php echo e(dateformatman($value->RegistrationStartDate)); ?></td>
             <td class="col-md-2"><?php echo e(dateformatman($value->RegistrationEndDate)); ?></td>
             <td class="col-md-2"><?php echo e(dateformatman($value->InsuranceStartDate)); ?></td>
             <td class="col-md-2"><?php echo e(dateformatman($value->InsuranceEndDate)); ?></td>
             <td class="col-md-2"><?php echo e($value->InsuranceCompanyName); ?></td>
             <td class="col-md-2"><?php echo e($value->LastReading); ?></td>
             <td class="col-md-2"><?php echo e(dateformatman($value->OilChangeDate)); ?></td>
             <td class="col-md-2"><?php echo e(dateformatman($value->OilDueDate)); ?></td>
             
             
         
              <td class="col-md-1"><a href="<?php echo e(URL('/FleetDetailDelete/'.$value->FleetDetailID)); ?>">Delete</a></td>
              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
             </tbody>
             </table>
             <?php else: ?>
               <p class=" text-danger">No data found</p>
             <?php endif; ?>   


        </div>
    </div>                   



                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/fleet_detail.blade.php ENDPATH**/ ?>
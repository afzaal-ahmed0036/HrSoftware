

<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18"> Official Notices</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         

                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3"  id="success-alert">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            
                           
                                  <table class="table table-sm align-middle table-nowrap mb-0">
                                        
                                         <tr >
                                        <th style="width: 10px;" >S.No</th>
                                        <th style="width: 600px;" >Title</th>
                                         <th style="width: 10px;" >Status</th>
                                        <th style="width: 10px;" >Date</th>
                                        <th style="width: 10px;" >View</th>
                                         </tr>
                                        
                                        <tbody>
                                         <?php if(!$notice->isEmpty()): ?>        
                                        <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr valign="top" >
                                         <td ><?php echo e($key+1); ?></td>
                                         <td ><?php echo e($value->Title); ?></td>
                                         
                                         <td ><span class="badge  <?php echo e(($value->Status=='Draft') ?'badge bg-warning' : 'bg-primary'); ?>"><?php echo e($value->Status); ?></span></td>
                                         <td ><?php echo e(dateformatman($value->Date)); ?></td>
                                         <td><a href="<?php echo e(URL('/NoticeBoardView/').'/'.$value->NoticeBoardID); ?>" target="_blank"><i class="mdi mdi-eye"></i></a></td>
                                         
                                        
                                         </tr>
                                        
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                          <?php else: ?>
                                           
                                         <tr>
                                             <td colspan="6" class="bg bg-light text-center">
                                           No data found      
                                             </td>
                                         <?php endif; ?>
                                         </tr> 
                                         </tbody>
                                         </table>   

                            
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->

                           
            </div>
            <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.staff_tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_notice_board.blade.php ENDPATH**/ ?>
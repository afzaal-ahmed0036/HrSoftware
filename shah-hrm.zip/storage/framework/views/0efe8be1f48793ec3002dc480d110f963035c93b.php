
<?php $__env->startSection('title', 'HR'); ?>
<?php $__env->startSection('content'); ?>
 <div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">FCB Top Agent Report</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row">
                <div class="col-xl-12">
                    <?php if(session('error')): ?>
                    <div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                        <strong><?php echo e(Session::get('error')); ?> </strong>
                    </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?> 
                    <div>
                        <div class="alert alert-danger pt-3 pl-0 border-3 bg-danger text-white">
                            <p class="font-weight-bold"> There were some problems with your input.</p>
                            <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="card ">
                        <div class="card-body">
                            <h4 class="card-title mb-4"></h4>
                            <form action="<?php echo e(URL('/TopAgentReport')); ?>" method="post">
                                <?php echo e(csrf_field()); ?> 
                                <div class="row">
                                    <div class="col-md-4">
                                       <div class="mb-3">
                                            <label for="basicpill-firstname-input">Branch*</label>
                                            <select name="BranchID" id="BranchID" class="form-select">
                                                <option value="">--Select Branch--</option>
                                                <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->BranchID); ?>" <?php echo e((@$branch_id== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="basicpill-firstname-input">Month*</label>
                                            <div class="input-group">
                                                <input type="month" id="month" name="month" class="form-control" value="<?php echo e(@$active_monthYear); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-success w-lg float-right filter" style="float:right;">Search</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- end card body -->
                    </div> 
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">FCB Top Agent Report</h4>
                            <table id="datatable" class="table table-bordered table-sm dt-responsive nowrap w-100 dataTable no-footer dtr-inline" role="grid" aria-describedby="datatable_info" style="width: 1247px;">
                                <thead>
                                    <tr role="row" >
                                    <th scope="col" >S.No</th>
                                    <th scope="col">Agent</th>
                                    <th scope="col">FTD </th>
                                    <th scope="col">Amount</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($fcbsummary) >0): ?> 
                                    <?php $i=1; ?>
                                    <?php $__currentLoopData = $fcbsummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                    <tr>
                                    <td><?php echo e($i); ?>.</td>
                                    <td><?php echo e($value->FirstName); ?> <?php echo e($value->MiddleName); ?> <?php echo e($value->LastName); ?></td>
                                    <td><?php echo e($value->tot); ?></td>
                                    <td><?php echo e(number_format($value->SumFTDAmount,2)); ?></td>
                                    </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php endif; ?>
                                </tbody>
                            </table>
                           
                            <?php if(count($fcbsummary) ==0): ?> 
                            <p class="text-danger h6">No record to display</p>
                            <?php endif; ?>
                        </div>
                        <!-- end card body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->  
        </div> <!-- container-fluid -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/fcb_top_agent_report.blade.php ENDPATH**/ ?>
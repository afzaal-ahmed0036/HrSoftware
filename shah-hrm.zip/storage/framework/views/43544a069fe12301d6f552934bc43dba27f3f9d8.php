
<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>
<style>
    .main-content {

    overflow: visible;
}
</style>
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Deals</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         

                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3"  id="success-alert">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

            <div class="row">
          <div class="card">
                    <div class="card-header bg-transparent border-bottom">
                          Mangae Deals
                      </div>
                      <div class="card-body">
                        
                        
                         <?php if($target->isNotEmpty()): ?> 
                        <table class="table table-sm align-middle table-nowrap mb-0">
                        <tbody><tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Target Type</th>
                        <th scope="col">Name</th>
                        <th scope="col">Target Period</th>
                        <th scope="col">Detail</th>
                        
                        <th scope="col">Start Date</th>
                        <th scope="col">End Date</th>
                        
                        <th scope="col">Date</th>
                        <th scope="col">Delete</th>
                        </tr>
                        </tbody>
                        <tbody>
                        <?php $__currentLoopData = $target; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                         <td class="col-md-1"><?php echo e($key+1); ?></td>
                         <td class="col-md-1"><?php echo e($value->TargetType); ?></td>
                         <td class="col-md-1"><?php echo e($value->TargetName); ?></td>
                         <td class="col-md-1"><?php echo e($value->TargetPeriod); ?></td>
                         <td class="col-md-1"><?php echo e($value->Detail); ?></td>
                        
                         <td class="col-md-1"><?php echo e(dateformatman($value->StartDate)); ?></td>
                         <td class="col-md-1"><?php echo e(dateformatman($value->EndDate)); ?></td>
                         <td class="col-md-1"><?php echo e(dateformatman($value->Date)); ?></td>
                         
                         <td class="col-md-1"><a href="<?php echo e(URL('/StaffTargetReply').'/'.$value->TargetID); ?>">Reply</a></td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                         </tbody>
                         </table>
                         <?php else: ?>
                           <p class=" text-danger">No data found</p>
                         <?php endif; ?>   


                      </div>
                  </div>     
                
         <div class="card">
         <div class="card-header bg-transparent border-bottom">
         <!-- enctype="multipart/form-data" -->
         <form action="<?php echo e(URL('/StaffTargetReplySave')); ?>" method="post">
          <?php echo e(csrf_field()); ?>




  <div class="col-md-4">
<div class="mb-3">
<label for="basicpill-firstname-input">Name*</label>
<input type="text" class="form-control form-con-sm" name="TargetID" value="<?php echo e(request()->id); ?> ">
</div>
</div>


    <div class="col-md-4">
   <div class="mb-3">
   <label for="basicpill-firstname-input"> Date *</label>                                   
  <div class="input-group" id="datepicker2">
   <input type="text" name="Date" autocomplete="off" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true" value="<?php echo e(date('d/m/Y')); ?>">
   <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
     </div>
  </div>
 </div>

<div class="col-md-4">
<div class="mb-3">
<label for="verticalnav-address-input">Detail</label>
<textarea id="verticalnav-address-input" class="form-control" rows="" name="Detail"></textarea>
</div>
</div>

 

<div><button type="submit" class="btn btn-success w-lg float-right">Save </button>
     
</div>



           </form>
         </div>
         <div class="card-body">      

         </div>
         </div>
                  

   
            </div>
            

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.staff_tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_target_reply.blade.php ENDPATH**/ ?>
  <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="me-3">

                                              <?php if($employee[0]->Picture!=null){ ?>
                                                <img src="<?php echo e(URL('/emp-picture/'.$employee[0]->Picture)); ?>" alt="" class="avatar-md rounded  ">  
                                              <?php } 
                                              else
                                              {


                                              ?>

                                                <img src="<?php echo e(asset('assets/images/users/avatar.png')); ?>" alt="" class="avatar-md rounded  ">

                                            <?php } ?>

                                            </div>
                                            <div class="media-body align-self-center">
                                                <div class="text-muted">
                                                    <h5><?php echo e($employee[0]->Title); ?> <?php echo e($employee[0]->FirstName); ?> <?php echo e($employee[0]->MiddleName); ?> <?php echo e($employee[0]->LastName); ?></h5>
                                                    <p class="mb-1"><?php echo e($employee[0]->JobTitleName); ?> , <?php echo e($employee[0]->DepartmentName); ?>,  <span class="badge badge-soft-success font-size-11 me-2 ml-5"> <?php echo e($employee[0]->StaffType); ?>  </span> </p>
                                                    <p class="mb-0"><?php echo e($employee[0]->BranchName); ?></p>
                                                     
                                                </div>
                                            </div>
                                    

                                                    
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_info.blade.php ENDPATH**/ ?>
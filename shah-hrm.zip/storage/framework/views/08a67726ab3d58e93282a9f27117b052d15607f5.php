

<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script type="text/javascript">

           

         function view_data(id)
    {
 window.open("<?php echo e(URL('/LeaveDetail')); ?>/"+id,"_self"); 
//alert(id);
    }  

     function edit_data(id)
    {
 window.open("<?php echo e(URL('/LeaveEdit')); ?>/"+id,"_self"); 
//alert(id);
    }

    function del_data(id)
    {

        var txt;
var r = confirm("Do you want to delete");
if (r == true) {
   window.open("<?php echo e(URL('/LeaveDelete')); ?>/ "+id,"_self");  
} else {
  txt = "You pressed Cancel!";
}



//alert(id);
    }

        </script>
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-9">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 " id="success-alert">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('emp.emp_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                             <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Offical Details
                                    </div>
                                    <div class="card-body">

                                        <form action="<?php echo e(URL('/LeaveUpdate')); ?>" method="post"> 
                                            <?php echo e(csrf_field()); ?> 

<input type="hidden" name="LeaveID" value="<?php echo e($leave[0]->LeaveID); ?>">

<?php 

$BranchID = old('BranchID') ? old('BranchID') : $leave[0]->BranchID ;
$FromDate = old('FromDate') ? old('FromDate') : dateformatman($leave[0]->FromDate) ;
$ToDate = old('ToDate') ? old('ToDate') : dateformatman($leave[0]->ToDate) ;
 $Reason = old('Reason') ? old('Reason') : $leave[0]->Reason ;
 $DaysApproved = old('DaysApproved') ? old('DaysApproved') : $leave[0]->DaysApproved ;
 $DaysRemaining = old('DaysRemaining') ? old('DaysRemaining') : $leave[0]->DaysRemaining ;
 $FromTime = old('FromTime') ? old('FromTime') : $leave[0]->FromTime ;
 $ToTime = old('ToTime') ? old('ToTime') : $leave[0]->ToTime ;


 ?>
                                            
                                                <div class="col-md-4">
                                             <div class="mb-3">
                                                <label for="basicpill-firstname-input">Branch*</label>
                                                 <select name="BranchID" id="BranchID" class="form-select">
                                                <option value="">Select</option>

                                                 <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($value->BranchID); ?>" <?php echo e(($value->BranchID== $BranchID) ? 'selected=selected':''); ?>><?php echo e($value->BranchName); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                             
                                              </select>
                                              </div>
                                               </div>


                                               
                                                   <div class="col-md-4">
                                                <div class="mb-3">
                                                   <label for="basicpill-firstname-input">Employee Name*</label>
                                                    <select name="EmployeeID" id="EmployeeID" class="form-select">
                                            
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($value->EmployeeID); ?>" <?php echo e((old('EmployeeID')== $value->EmployeeID) ? 'selected=selected': ''); ?>><?php echo e($value->FirstName); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                                 </select>
                                                 </div>
                                                  </div>
                                               
                                               
<div class="row">
    
                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">From Date *</label>
                                                                 

                                                                   <input name="FromDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e($FromDate); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div>
                                                <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">To Date *</label>
                                                                 

                                                                   <input name="ToDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e($ToDate); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div>


                                        <div class="col-md-2">
                                      <div class="mb-3">
                                      <label for="basicpill-firstname-input"><span class="text-danger">Days Approved</span></label>
                                      <input type="text" class="form-control" name="DaysApproved" value="<?php echo e($DaysApproved); ?> ">
                                      </div>
                                      </div>   

                                       <div class="col-md-2">
                                      <div class="mb-3">
                                      <label for="basicpill-firstname-input"><span class="text-success">Days Remaining</span></label>
                                      <input type="text" class="form-control" name="DaysRemaining" value="<?php echo e($DaysRemaining); ?> ">
                                      </div>
                                      </div>
                                      
                                      
     <div class="row">
  <div class="col-md-2"><div class="mb-3">
<label class="form-label">Time From </label>

<div class="input-group" id="timepicker-input-group2">
<input  name="FromTime"  id="timepicker2" type="text" class="form-control" data-provide="timepicker" value="<?php echo e($FromTime); ?>">

 </div>
</div></div>
  <div class="col-md-2"><div>
<label class="form-label">To Time</label>

<div class="input-group" id="timepicker-input-group2-to">
<input  name="ToTime"  id="timepicker2_to" type="text" class="form-control" data-provide="timepicker" value="<?php echo e($ToTime); ?>">

 </div>
</div></div>
</div>
                                 

                                      <div class="col-md-12">
                                                            <div class="mb-3">
                                                                <label for="verticalnav-address-input">Reason</label>
                                                                <textarea id="verticalnav-address-input" class="form-control" rows="" name="Reason"><?php echo e($Reason); ?></textarea>
                                                            </div>
                                                        </div>
</div>
                                               
                                               
                                               
                                               
                                            

                                            
                                            

                                           
                                            

                                      

 
                                    </div>
                                </div>
                                <!-- end card -->



                                <div class="card">
                                    <div class="card-body">
                                      <h5>Operational Manager</h5>
                                      <hr>

                                      
                                   
                                    
                                  <div class="row">
                                    
                                          <div class="col-md-4">
                                     <div class="mb-3">
                                        <label for="basicpill-firstname-input">Approval</label>
                                         <select name="OMStatus" id="OMStatus" class="form-select" <?php echo e((session::get('UserType')=='OM') ? '' : 'disabled'); ?>>
                                        <option value="">Select</option>
                                        <option value="Pending" <?php echo e(($leave[0]->OMStatus=='Pending') ? 'selected=selected':''); ?>>Pending</option>
                                        <option value="Yes" <?php echo e(($leave[0]->OMStatus=='Yes') ? 'selected=selected':''); ?>>Yes</option>
                                        <option value="No" <?php echo e(($leave[0]->OMStatus=='No') ? 'selected=selected':''); ?>>No</option>
                                        
                                       
                                     
                                      </select>
                                      </div>
                                       </div>
                                    

                                    <div class="col-md-4">
                                  <div class="mb-3">
                                  <label for="basicpill-firstname-input">Checked on</label>
                                  <input type="text" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" name="OMStatusDate" value="<?php echo e($leave[0]->OMStatusDate); ?>" <?php echo e((session::get('UserType')=='OM') ? '' : 'disabled'); ?>>
                                  <span class="text-muted">e.g "dd/mm/yyyy"</span>
                                  </div>
                                  </div>




                                    
                                    <div class="col-md-12">
                                    <div class="mb-3">
                                    <label for="verticalnav-address-input">Remarks if any</label>
                                    <textarea id="verticalnav-address-input" class="form-control" rows="" name="OMRemarks" <?php echo e((session::get('UserType')=='OM') ? '' : 'disabled'); ?>><?php echo e($leave[0]->OMRemarks); ?> </textarea>
                                    </div>
                                    </div>
                                  </div>

                                      
                                      
                                    </div>
                                </div>
                                



                                 <div class="card">
                                    <div class="card-body">
                                      <h5>HR Manager</h5>
                                      <hr>

                                      
                                     
                                    
                                  <div class="row">
                                    
                                          <div class="col-md-4">
                                     <div class="mb-3">
                                        <label for="basicpill-firstname-input">Approval</label>
                                        <select name="HRStatus" id="HRStatus" class="form-select" <?php echo e((session::get('UserType')=='HR') ? '' : 'disabled'); ?>>
                                        <option value="">Select</option>
                                        <option value="Pending" <?php echo e(($leave[0]->HRStatus=='Pending') ? 'selected=selected':''); ?>>Pending</option>
                                        <option value="Yes" <?php echo e(($leave[0]->HRStatus=='Yes') ? 'selected=selected':''); ?>>Yes</option>
                                        <option value="No" <?php echo e(($leave[0]->HRStatus=='No') ? 'selected=selected':''); ?>>No</option>
                                     
                                      </select>
                                      </div>
                                       </div>
                                    

                                    <div class="col-md-4">
                                  <div class="mb-3">
                                  <label for="basicpill-firstname-input">Checked on</label>
                                  <input type="text" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" name="HRStatusDate" value="<?php echo e($leave[0]->HRStatusDate); ?>" <?php echo e((session::get('UserType')=='HR') ? '' : 'disabled'); ?> >

                              
                                                   <span class="text-muted">e.g "dd/mm/yyyy"</span>


                                  </div>
                                  </div>




                                    
                                    <div class="col-md-12">
                                    <div class="mb-3">
                                    <label for="verticalnav-address-input">Remarks if any</label>
                                    <textarea id="verticalnav-address-input" class="form-control" rows="" name="HRRemarks" <?php echo e((session::get('UserType')=='HR') ? '' : 'disabled'); ?> ><?php echo e($leave[0]->HRRemarks); ?></textarea>
                                    </div>
                                    </div>
                                  </div>

                                      
                                      
                                    </div>
                                </div>
                                

                                 <div class="card">
                                    <div class="card-body   ">
                                      <h5>General Manager</h5>
                                      <hr>



                                    
                                  <div class="row">
                                    
                                          <div class="col-md-4">
                                     <div class="mb-3">
                                        <label for="basicpill-firstname-input">Approval</label>
                                          <select name="GMStatus" id="GMStatus" class="form-select" <?php echo e((session::get('UserType')=='GM') ? '' : 'disabled'); ?>>
                                        <option value="">Select</option>
                                        <option value="Pending" <?php echo e(($leave[0]->GMStatus=='Pending') ? 'selected=selected':''); ?>>Pending</option>
                                        <option value="Yes" <?php echo e(($leave[0]->GMStatus=='Yes') ? 'selected=selected':''); ?>>Yes</option>
                                        <option value="No" <?php echo e(($leave[0]->GMStatus=='No') ? 'selected=selected':''); ?>>No</option>
                                     
                                      </select>
                                      </div>
                                       </div>
                                    
 


                                  
                                    <div class="col-md-4">
                                             <div class="mb-3">
                                               <label for="basicpill-firstname-input">Checked on</label>
                                                   <input name="GMStatusDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e($leave[0]->GMStatusDate); ?>" <?php echo e((session::get('UserType')=='GM') ? '' : 'disabled'); ?>" >
                                                   <span class="text-muted">e.g "dd/mm/yyyy"</span>
                                      </div>
                                    </div> 
                                  


 

                                    
                                    <div class="col-md-12">
                                    <div class="mb-3">
                                    <label for="verticalnav-address-input">Remarks if any</label>
                                    <textarea id="verticalnav-address-input" class="form-control" rows="" name="GMRemarks" <?php echo e((session::get('UserType')=='GM') ? '' : 'disabled'); ?> ><?php echo e($leave[0]->GMRemarks); ?></textarea>
                                    </div>
                                    </div>
                                  </div>

                                       <div><button type="submit" class="btn btn-success w-md float-right">Update </button>
                                                 <a href="<?php echo e(URL('/Leave')); ?>" class="btn btn-secondary w-md float-right">Cancel</a>
                                            </div>
                                      
                                    </div>


                                </div>
                                  </form>

                                 <!-- start page title -->
                 
                        <!-- end page title -->


 



                            </div>
                            <!-- end col -->
                         
                         <!-- employee detail side bar -->
                         <?php echo $__env->make('template.emp_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>

<script type="text/javascript">
 

$("#success-alert").fadeTo(4000, 500).slideUp(100, function(){
    // $("#success-alert").slideUp(500);
    $("#success-alert").alert('close');
});


</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/emp/leave_edit.blade.php ENDPATH**/ ?>
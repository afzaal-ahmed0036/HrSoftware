

<?php $__env->startSection('title', 'HR'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">EU Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>

                                        <form action="<?php echo e(URL('/EUSave')); ?>" method="post"  >

                                         <?php echo e(csrf_field()); ?> 

                                         <div class="row">
                                          


                                                 
                                                     
                                     
                                                         <div class="col-md-2">
                                                   <div class="mb-3">
                                                      <label for="basicpill-firstname-input">Month*</label>
                                                       <select name="MonthName" id="MonthName" class="form-select">
                                                       <?php $__currentLoopData = $monthname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <option value="<?php echo e($value->MonthName); ?>"><?php echo e($value->MonthName); ?></option>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                     </select>
                                                    </div>
                                                     </div>

                                                           <div class="col-md-4">
                                                   <div class="mb-3">
                                                      <label for="basicpill-firstname-input">Branch*</label>
                                                       <select name="BranchID" id="BranchID" class="form-select">
                                                       <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <option value="<?php echo e($value->BranchID); ?>"><?php echo e($value->BranchName); ?></option>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                     </select>
                                                    </div>
                                                     </div>
                                                   
                                                   <div class="clearfix"></div>
                                                     
                                                       <div class="col-md-2">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">No*</label>
                                         <input type="text" class="form-control" name="No" value="<?php echo e(old('No')); ?> " id="No">
                                         </div>
                                         </div>     

                                         
                                                       <div class="col-md-2">
                                                     <div class="mb-3">
                                                     <label for="basicpill-firstname-input">Sum*</label>
                                                     <input type="text" class="form-control" name="Sum" value="<?php echo e(old('Sum')); ?> " id="Sum1">
                                                     </div>
                                                     </div>  

                                                      <div class="col-md-2">
                                                     <div class="mb-3">
                                                     <label for="basicpill-firstname-input">NetDeposit*</label>
                                                     <input type="text" class="form-control" name="NetDeposit" value="<?php echo e(old('NetDeposit')); ?> " id="NetDeposit">
                                                     </div>
                                                     </div>
                                                      <div class="clearfix"></div>
                                                         <div class="col-md-2">
                                                     <div class="mb-3">
                                                     <label for="basicpill-firstname-input">FTD*</label>
                                                     <input type="text" class="form-control" name="FTD" value="<?php echo e(old('FTD')); ?> " id="FTD">
                                                     </div>
                                                     </div>
                                                          
                                   
                                        

                                         	<div><button type="submit" class="btn btn-success w-lg float-right">Save</button>
                                         	     
                                         	</div>
                                         	
                                         
                                         </div>
                                         
                                     
                                         
                              
                                         
                                         

                                     </form>

                                        
                                    </div>
                                    <!-- end card body -->
                                </div> 

                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4">EU Overall Detail Monthwise</h4>


                                               <?php if(count($eu) >0): ?> 
                                        <div class="table-responsive">
                                            <table class="table table-sm align-middle table-nowrap mb-0">
                                                <thead><tr class="bg-light">
                                                    <th scope="col" >S.No</th>
                                                    <th scope="col">Month</th>
                                                    <th scope="col">No</th>
                                                    <th scope="col">Sum</th>
                                                    <th scope="col">Net Deposit</th>
                                                    <th scope="col">FTD</th>
                                                    <th scope="col">Per</th>
                                                    <th scope="col">Total</th>
                                                    <th scope="col">AED</th>
                                                    
                                                    <th scope="col">Entry Date</th>
                                                    <th scope="col">Manage</th>
                                                  </tr>
                                                </thead> 
                                               <?php $i=1; ?>
                                               <?php $__currentLoopData = $eu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                               <?php 

$result = eu($value->No,$value->Sum,$value->NetDeposit,$value->FTD,$value->Per,$value->Total );

 

                                                ?>
                                                    <tr>
                                                        <td class="col-md-1"><?php echo e($i); ?>.</td>
                                                         
                                                        <td class="col-md-2"><?php echo e($value->MonthName); ?></td>
                                                        <td class="col-md-1"><?php echo e($value->No); ?> </td>
                                                        <td class="col-md-1"><?php echo e(number_format($value->Sum,2)); ?></td>
                                                        <td class="col-md-1"><?php echo e(number_format($value->NetDeposit,2)); ?></td>
                                                        <td class="col-md-1"><?php echo e(number_format($value->FTD,2)); ?></td>
                                                        <td class="col-md-1"><?php echo e(number_format($value->Per,2)); ?></td>
                                                        <td class="col-md-1"><?php echo e(number_format($eu[0]->Total,2)); ?></td>
                                                        <td class="col-md-1"> <?php echo e(number_format($result['AED'],2)); ?></td>
                                                        <td class="col-md-1"><?php echo e($value->eDate); ?></td>
                                                            
                                                             
                                                         
                                                        <td class="col-md-1">
                                                            <a href="<?php echo e(URL('/EUView/'.$value->EuID)); ?>"><i class="mdi mdi-eye-outline align-middle me-1"></i></a>

                                                              <a href="<?php echo e(URL('/EUEdit/'.$value->EuID)); ?>"><i class="bx bx-pencil align-middle me-1"></i></a>

                                                             <a href="#" onclick="delete_confirm2('EUDelete',<?php echo e($value->EuID); ?>)"><i class="bx bx-trash  align-middle me-1"></i></a>

                                                             

                                                         </td>
                                                        <td>
                                                            
                                                        </td>
                                                    </tr>
                                                   <?php $i++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     

                                                   
                                                
                                            </table>
                                            
                                              
                                        </div>
                                        <?php endif; ?>

                                          <?php if(count($eu) ==0): ?> 
                                        <p class="text-danger h6">No record to display</p>

                                        <?php endif; ?>
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>
   



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/eu.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Branches'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Branches</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>

                                        <form action="<?php echo e(URL('/BranchUpdate')); ?>" method="post" enctype="multipart/form-data">

                                        <input type="hidden" name="BranchID" value="<?php echo e($branch[0]->BranchID); ?> ">

                                         <?php echo e(csrf_field()); ?> 

                                         <div class="row">
                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Branch*</label>
                                         <input type="text" class="form-control" name="BranchName" value="<?php echo e($branch[0]->BranchName); ?> ">
                                         </div>
                                         </div>
                                         

                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Contact*</label>
                                         <input type="text" class="form-control" name="BranchContact" value="<?php echo e($branch[0]->BranchContact); ?> ">
                                         </div>
                                         </div>
                                         
                                         
                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Email*</label>
                                         <input type="text" class="form-control" name="BranchEmail" value="<?php echo e($branch[0]->BranchEmail); ?> ">
                                         </div>
                                         </div>

                                               <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Address*</label>
                                         <input type="text" class="form-control" name="BranchAddress" value="<?php echo e($branch[0]->BranchAddress); ?> ">
                                         </div>
                                         </div>

                                         <div class="col-md-4">
                                         	<div class="mb-3"><label for="basicpill-firstname-input" class="pr-5">Branch Logo</label><br><input type="file" name="BranchLogo" id="BranchLogo"></div></div>


                                         	<div><button type="submit" class="btn btn-success w-lg float-right">Save</button>
                                         	     
                                         	</div>
                                         	
                                         
                                         </div>
                                         
                                     
                                         
                                         
                                         
                                         
                                         
                                         

                                     </form>

                                        
                                    </div>
                                    <!-- end card body -->
                                </div> 
  
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/branchedit.blade.php ENDPATH**/ ?>
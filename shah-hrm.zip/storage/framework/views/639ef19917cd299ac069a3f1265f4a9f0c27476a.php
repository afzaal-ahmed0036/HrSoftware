

<?php $__env->startSection('title', 'Employee'); ?>
 

<?php $__env->startSection('content'); ?>


  


 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                          
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Emplyee Section</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here <-->
                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2 w-md"><i class="mdi mdi-arrow-left pr-3"></i> Go Back</a>
                                         </-->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->


 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>


<form action="<?php echo e(URL('/EmployeeSave')); ?>" method="post" enctype="multipart/form-data">
                        <div class="row">
 
 <?php echo e(csrf_field()); ?>


                          
                            <div  >
                                 <div class="card">
                   <div class="card-header bg-transparent border-bottom h5">

                                                                  Personal Information
                                                              </div>
          <div class="card-body">
                                                                <!-- start of personal detail row -->
      <div class="row">
                                                           <div class="col-md-4">
                <div class="mb-3"><label for="basicpill-firstname-input" class="pr-5">Staff Picture</label><br><input type="file" name="UploadSlip" id="UploadSlip" >
                </div>
        </div>       <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Branch <span class="text-danger">*</span></label>
                                                                <select name="BranchID" id="BranchID" class="form-select">
                                                                    <option value="">---Select---</option>
                                                                    <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($value->BranchID); ?>" <?php echo e((old('BranchID')== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                        </div>

 <div class="col-lg-2">  
  <div class="form-group">
   <label class="control-label" for="IsSupervisor">Is Supervisor? <span class="text-danger">*</span>
</label>
  </div>     <div class="form-check form-check-inline pt-1">
  <input class="form-check-input" type="radio" name="IsSupervisor" id="inlineRadio1" value="Yes" <?php echo e(old('IsSupervisor') == 'Yes' ? 'checked' : ''); ?> required="">
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" required="" name="IsSupervisor" id="inlineRadio2" value="No"   <?php echo e(old('IsSupervisor') == 'No' ? 'checked' : ''); ?>>
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>
 </div>

  <div class="col-lg-2">
 <div class="mb-3">
  <label for="basicpill-firstname-input">Staff Type <span class="text-danger">*</span></label>
  <select name="StaffType" id="StaffType" class="form-select">
     <?php $__currentLoopData = $staff_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($value->StaffType); ?>" <?php echo e((old('StaffType')== $value->StaffType) ? 'selected=selected': ''); ?>><?php echo e($value->StaffType); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
</select>
</div>
 </div>
                                        
 

    <div class="col-md-4">
 <div class="mb-3">
    <label for="basicpill-firstname-input">Title </label>
     <select name="Title" id="Title" class="form-select">
    
     <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($value->Title); ?>" <?php echo e((old('Title')== $value->Title) ? 'selected=selected': ''); ?>><?php echo e($value->Title); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
 
  </select>
  </div>
   </div>



                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">First Name</label>
                                                                <input type="text" class="form-control" name="FirstName" value="<?php echo e(old('FirstName')); ?> ">
                                        </div>


                                      </div>

                                      <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Middle Name</label>
                                                                <input type="text" class="form-control" name="MiddleName" value="<?php echo e(old('MiddleName')); ?> ">
                                        </div>


                                      </div>

                                      <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Last Name</label>
                                                                <input type="text" class="form-control" name="LastName" value="<?php echo e(old('LastName')); ?> ">
                                        </div>


                                      </div> 
                                        
                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Date of Birth <span class="text-danger">*</span></label>
                                                                 

                                                                   <input name="DateOfBirth" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('DateOfBirth')); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div> 

                                         <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Gender</label>
                                                                <select name="Gender" id="Gender" class="form-select">
                                                                    <option value="Male">Male</option>
                                                                    <option value="Female">Female</option>
                                                                </select>
                                                            </div>
                                        </div>

                                              <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Email <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control" name="Email" value="<?php echo e(old('Email')); ?> ">
                                        </div>


                                      </div> 

                                         <div class="col-md-4">
<div class="mb-3">
    <label for="basicpill-firstname-input">Nationality</label>
    <select name="Nationality" id="Nationality" class="form-select select2">
        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value->CountryName); ?>" <?php echo e((old('Nationality')== $value->CountryName) ? 'selected=selected': ''); ?>><?php echo e($value->CountryName); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
</div> 

                                            <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Mobile No</label>
                                                                <input type="text" class="form-control" name="MobileNo" value="<?php echo e(old('MobileNo')); ?> ">
                                        </div>


                                      </div>   

                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Home Phone</label>
                                                                <input type="text" class="form-control" name="HomePhone" value="<?php echo e(old('HomePhone')); ?> ">
                                        </div>


                                      </div> 

                                       <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Full Address</label>
                                                                <input type="text" class="form-control" name="FullAddress" value="<?php echo e(old('FullAddress')); ?> ">
                                        </div>


                                      </div> 

                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Education Level</label>
                                                                <select name="EducationLevel" id="EducationLevel" class="form-select">
                                                                    
                                                                     <?php $__currentLoopData = $educationlevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                      <option value="<?php echo e($value->EducationLevelName); ?>" <?php echo e((old('EducationLevel')== $value->EducationLevelName) ? 'selected=selected': ''); ?>><?php echo e($value->EducationLevelName); ?></option>
                                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    
                                                                </select>
                                                            </div>
                                        </div>

                                           <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Last Degree</label>
                                                                <input type="text" class="form-control" name="LastDegree" value="<?php echo e(old('LastDegree')); ?> ">
                                        </div>


                                      </div>
                                                                </div>
                                                                <!-- end of personal detail row -->
                                                              </div>
                                                          </div>
                                

                                    <div class="card">
                                       <div class="card-header bg-transparent border-bottom h5">
                                             Marital Detail
                                        </div>
                                      <div class="card-body">
                                    <div class="row">
                                       <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Marital Status</label>
                                                                <select name="MaritalStatus" id="MaritalStatus" class="form-select">
                                                                    <option value="Single">Single</option>
                                                                    <option value="Married">Married</option>
                                                                </select>
                                                            </div>
                                        </div>

                                         <div class="col-md-4 d-none">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">SSN or GID</label>
                                                                <input type="text" class="form-control" name="SSNorGID" value="<?php echo e(old('SSNorGID')); ?> ">
                                        </div>


                                      </div> 


                                        <div class="clearfix"></div>

                                         

                                         <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Spouse Name</label>
                                                                <input type="text" class="form-control" name="SpouseName" value="<?php echo e(old('SpouseName')); ?> ">
                                        </div>


                                      </div> 

                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Spouse Address</label>
                                                                <input type="text" class="form-control" name="SpouseEmployer" value="<?php echo e(old('SpouseEmployer')); ?> ">
                                        </div>


                                      </div> 

                                       <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Spouse Work Phone</label>
                                                                <input type="text" class="form-control" name="SpouseWorkPhone" value="<?php echo e(old('SpouseWorkPhone')); ?> ">
                                        </div>


                                      </div>

                                    </div>
                                         </div>
                                   </div>
                                                                                   



                                     <div class="card">
                                                                     <div class="card-header bg-transparent border-bottom h5">
                                                                           Visa / Passport Section
                                                                       </div>
                                                                       <div class="card-body">
                                                                        <div class="row">
                                                                          
  <div class="col-md-4 ">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Visa Issue Date</label>
                                                                 

                                                                   <input name="VisaIssueDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('VisaIssueDate')); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div>  

                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Visa Expiry Date</label>
                                                                 

                                                               <input name="VisaExpiryDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('VisaExpiryDate')); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div>
  <div class="clearfix"></div>
                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Passport No</label>
                                                                 

                                                                <input name="PassportNo" id="input-date1" class="form-control"  value="<?php echo e(old('PassportNo')); ?>"  >
                                                            



                                                            </div>

                                      </div>  

                                       <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Passport Expiry</label>
                                                                 

                                                                  <input name="PassportExpiry" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('PassportExpiry')); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div>  
  <div class="clearfix"></div>
                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Emirates ID No</label>
                                                                 

                                                                 <input name="EidNo" id="input-date1" class="form-control"  value="<?php echo e(old('EidNo')); ?>"  >



                                                            </div>

                                      </div>   

                                      <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Eid Expiry</label>
                                                                 

                                                               <input name="EidExpiry" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('EidExpiry')); ?>" im-insert="false">
                                                            <span class="text-muted">e.g "dd/mm/yyyy"</span>



                                                            </div>

                                      </div> 

                                                                        </div> 
                                                                       </div>
                                                                   </div>
                                                                     



  <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5">
                                        Next of Kin 
                                    </div>
                                    <div class="card-body">
                                      <div class="row">
                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Next of Kin Name  </label>
                                                                <input type="text" class="form-control" name="NextofKinName" value="<?php echo e(old('NextofKinName')); ?> ">
                                        </div>


                                      </div>

                                        <div class="col-md-4">
                                         <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Next of Kin Address </label>
                                                                <input type="text" class="form-control" name="NextofKinAddress" value="<?php echo e(old('NextofKinAddress')); ?> ">
                                        </div>


                                      </div>


                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Next of Kin Phone </label>
                                                                <input type="text" class="form-control" name="NextofKinPhone" value="<?php echo e(old('NextofKinPhone')); ?> ">
                                        </div>


                                      </div>


                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Next of Kin Relationship </label>
                                                                <input type="text" class="form-control" name="NextofKinRelationship" value="<?php echo e(old('NextofKinRelationship')); ?> ">
                                        </div>


                                      </div>

                                      </div>
                                    </div>
                                </div>




  <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Offical Details
                                    </div>
                                    <div class="card-body">
                                      <div class="row">
                                       

                                      <div class="clearfix"></div>


                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Job Title </label>
                                                                <select name="JobTitleID" id="JobTitleID" class="form-select">
                                                                   
                                                                    <?php $__currentLoopData = $jobtitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <option value="<?php echo e($value->JobTitleID); ?>" <?php echo e((old('JobTitleID')== $value->JobTitleID) ? 'selected=selected': ''); ?>><?php echo e($value->JobTitleName); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                   
                                                                </select>
                                                            </div>
                                        </div> 
                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Department </label>
                                                                <select name="DepartmentID" id="DepartmentID" class="form-select">
                                                                    
                                                                     <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                      <option value="<?php echo e($value->DepartmentID); ?>" <?php echo e((old('DepartmentID')== $value->DepartmentID) ? 'selected=selected': ''); ?>><?php echo e($value->DepartmentName); ?></option>
                                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    
                                                                </select>
                                                            </div>
                                        </div>

                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Supervisor </label>
                                                                <select name="SupervisorID" id="SupervisorID" class="form-select select2">
                                                                    <option value="">---Select---</option>
                                                                     <?php $__currentLoopData = $supervisor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                      <option value="<?php echo e($value->EmployeeID); ?>" <?php echo e((old('SupervisorID')== $value->EmployeeID) ? 'selected=selected': ''); ?>><?php echo e($value->FirstName); ?></option>
                                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    
                                                                </select>
                                                            </div>
                                        </div>

                                        <div class="clearfix"></div>

                                            <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Work Location </label>
                                                                <input type="text" class="form-control" name="WorkLocation" value="<?php echo e(old('WorkLocation')); ?> ">
                                        </div>


                                      </div>

                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Email Offical</label>
                                                                <input type="text" class="form-control" name="EmailOffical" value="<?php echo e(old('EmailOffical')); ?> ">
                                        </div>


                                      </div>

                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Work Phone</label>
                                                                <input type="text" class="form-control" name="WorkPhone" value="<?php echo e(old('WorkPhone')); ?> ">
                                        </div>


                                      </div>

                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Date of Joining <span class="text-danger">*</span></label>
                                                                 
        <input name="StartDate" id="input-date1" class="form-control input-mask" data-inputmask="'alias': 'datetime'" data-inputmask-inputformat="dd/mm/yyyy" value="<?php echo e(old('StartDate')); ?>" im-insert="false" required="">
                 <span class="text-muted">e.g "dd/mm/yyyy"</span>
                                        </div>




                                      </div>

                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Salary <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control" name="Salary" value="<?php echo e(old('Salary')); ?> " required="">
                                        </div>


                                      </div>

                                         <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Salary Comission (If Any)</label>
                                                                <input type="text" class="form-control" name="ExtraComission" value="<?php echo e(old('Salary')); ?> ">
                                        </div>


                                      </div>


                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Salary Remarks </label>
                                                                <input type="text" class="form-control" name="SalaryRemarks" value="<?php echo e(old('SalaryRemarks')); ?> ">
                                        </div>
                                      </div>



        <div><button type="submit" class="btn btn-success w-lg float-right">Save / Update</button>
 <a href="#" onclick="history.back()" class="btn btn-secondary w-md float-right">Cancel</a>                                     </div>
                                      </div>
                                    </div>
                                </div>

                        
                                <!-- end card -->


   <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5">
                                        Bank Details 
                                    </div>
                                    <div class="card-body">
                                      <div class="row">
                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Bank Name  </label>
                                                                <input type="text" class="form-control" name="BankName" value="<?php echo e(old('BankName')); ?> ">
                                        </div>


                                      </div>

                                        <div class="col-md-4">
                                         <div class="mb-3">
                                                                <label for="basicpill-firstname-input">IBAN # </label>
                                                                <input type="text" class="form-control" name="IBAN" value="<?php echo e(old('IBAN')); ?> ">
                                        </div>


                                      </div>


                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Account Title </label>
                                                                <input type="text" class="form-control" name="AccounTitle" value="<?php echo e(old('AccounTitle')); ?> ">
                                        </div>


                                      </div>


                                        <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">Salary Type </label>
                                                                <input type="text" class="form-control" name="SalaryType" value="<?php echo e(old('SalaryType')); ?> " placeholder="Cash/Bank">
                                        </div>


                                      </div>

                                      </div>
                                    </div>
                                </div>
                          
                                
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                       </form> 

                    

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


 
  <?php $__env->stopSection(); ?>

  redirect:



   
    
     
 

 
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/employeecreate.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Supervisor & Team Tree</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>
<div class="">
                                            <ul class="verti-timeline list-unstyled">
                                               
                                              <?php if(count($employee)>0): ?>  
                                              <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                  
                                            <?php  
                                                $team = DB::table('v_employee')->where('SupervisorID',$value->EmployeeID)->get();    
                                                ?>
                                                <li class="event-list">
                                                    <div class="event-timeline-dot">
                                                        <i class="bx bx-right-arrow-circle"></i>
                                                    </div>
                                                    <div class="media">
                                                        <div class="me-3">
                                                            <i class="bx bx-copy-alt h2 text-primary"></i>
                                                        </div>
                                                        <div class="media-body">
                                                            <div>
                                                                <h5><a href="<?php echo e(URL('/EmployeeEdit/'.$value->EmployeeID)); ?>" target="_blank">[<?php echo e($value->EmployeeID); ?>] - <?php echo e($value->FirstName); ?> <?php echo e($value->MiddleName); ?> <?php echo e($value->LastName); ?>, <?php echo e($value->JobTitleName); ?>, [<?php echo e($value->StaffType); ?>]</a> </h5>
                                                               
                                                                <?php if(count($team)>0): ?>
                                                                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <p class="text-muted">
                                                                    <a href="<?php echo e(URL('/EmployeeEdit/'.$value->EmployeeID)); ?>" target="_blank">[<?php echo e($value->EmployeeID); ?>] - <?php echo e($value->FirstName); ?> <?php echo e($value->MiddleName); ?> <?php echo e($value->LastName); ?>, <?php echo e($value->JobTitleName); ?>, [<?php echo e($value->StaffType); ?>]</a>
                                                                 </p>
                                                                    
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                 
                                             
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php endif; ?>      
                                                 
                                               
                                            </ul>
                                        </div>
                                        
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/team.blade.php ENDPATH**/ ?>
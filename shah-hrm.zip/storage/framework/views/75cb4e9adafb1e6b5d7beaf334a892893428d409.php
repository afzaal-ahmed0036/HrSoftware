

<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 ">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('staff.staff_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<div class="card">
       <div class="card-header bg-transparent border-bottom h5  ">
                                       Add Daily Task 
                                    </div>
    <div class="card-body">

      <!-- enctype="multipart/form-data" -->
      <form action="<?php echo e(URL('/DailyReportUpdate')); ?>" method="post"  > 

        <?php echo e(csrf_field()); ?> 


<input type="hidden" name="DailyReportID" value="<?php echo e($daily_report[0]->DailyReportID); ?>"> 

          <div class="col-md-4 mb-3">  <label for="basicpill-firstname-input">Date : </label>
           <?php echo e($daily_report[0]->Date); ?>

          </div>

          <div class="col-md-4">
        <div class="mb-3">
        <label for="basicpill-firstname-input">Title</label>
        <input type="text" class="form-control" name="Title" required="" value="<?php echo e($daily_report[0]->Title); ?>">
        </div>
        </div>
        

<div class="col-md-12">
<div class="mb-3">
<label for="verticalnav-address-input">Detail</label>
<textarea id="verticalnav-address-input" class="form-control" rows="4" name="Detail" required="" ><?php echo e($daily_report[0]->Detail); ?></textarea>
</div>
</div>



<div class="col-md-4">
  <div class="mb-3">
    <label for="basicpill-firstname-input">Any file/document<br></label>
    <br><a href="<?php echo e(URL('/reports/').'/'.$daily_report[0]->File); ?>" target="_blank">File</a>
  </div>
</div> 
        
        

<div class="col-md-12">
<div class="mb-3 ">
<label for="verticalnav-address-input">Supervisor Comments</label>
<textarea id="verticalnav-address-input" class="form-control border-1 border-danger" name="SupervisorComments" rows="4" name="Detail" required="" ></textarea>
</div>
</div>

        <div><button type="submit" class="btn btn-success  btn-sm float-right">Update</button>
             
        </div>
        

      </form>

    </div>
</div>


                             



 


                            </div>
                            <!-- end col -->
                         
                    

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.staff_tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_dailyreport_edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script type="text/javascript">

           

         function view_data(id)
    {
 window.open("<?php echo e(URL('/LeaveDetail')); ?>/"+id,"_self"); 
//alert(id);
    }  

     function edit_data(id)
    {
 window.open("<?php echo e(URL('/LeaveEdit')); ?>/"+id,"_self"); 
//alert(id);
    }

    function del_data(id)
    {

        var txt;
var r = confirm("Do you want to delete");
if (r == true) {
   window.open("<?php echo e(URL('/LeaveDelete')); ?>/ "+id,"_self");  
} else {
  txt = "You pressed Cancel!";
}



//alert(id);
    }

        </script>
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-9">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 " id="success-alert">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('emp.emp_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <?php if(Session::has('message')): ?>
<p class="alert alert-warning"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
           
          
           

                             <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Offical Details
                                    </div>
                                    <div class="card-body">

                                        <form action="<?php echo e(URL('/LeaveSave')); ?>" method="post"> 
                                            <?php echo e(csrf_field()); ?> 


                                            <div class="row">
                                              
                                                <div class="col-md-4">
                                             <div class="mb-3">
                                                <label for="basicpill-firstname-input">Leave Type*</label>
                                                 <select name="LeaveTypeID" id="LeaveTypeID" class="form-select" required="">
 
                                                 <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($value->LeaveTypeID); ?>"><?php echo e($value->LeaveTypeName); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                             
                                              </select>
                                              </div>
                                               </div>


                                               <div class="col-md-4">
                                             <div class="mb-3">
                                                <label for="basicpill-firstname-input">Branch*</label>
                                                 <select name="BranchID" id="BranchID" class="form-select" required="">
 
                                                 <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($value->BranchID); ?>" <?php echo e((old('BranchID')== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                             
                                              </select>
                                              </div>
                                               </div>


                                               
                                                   <div class="col-md-4">
                                                <div class="mb-3">
                                                   <label for="basicpill-firstname-input">Employee Name*</label>
                                                    <select name="EmployeeID" id="EmployeeID" class="form-select">
                                            
                                            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($value->EmployeeID); ?>" <?php echo e((old('EmployeeID')== $value->EmployeeID) ? 'selected=selected': ''); ?>><?php echo e($value->FirstName); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                                 </select>
                                                 </div>
                                                  </div>
                                               
                                            </div>
                                               
<div class="row">
    
                                          <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">From Date *</label>
                                                                 

                                                                    <div class="input-group" id="datepicker2">
  <input type="text" name="FromDate" autocomplete="off" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true">
  <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
    </div>
                                                            


 



                                                            </div>

                                      </div>
                                                  <div class="col-md-4">
                                                            <div class="mb-3">
                                                                <label for="basicpill-firstname-input">From Date *</label>
                                                                 

                                                                    <div class="input-group" id="datepicker21">
  <input type="text" name="ToDate"  autocomplete="off" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker21" data-provide="datepicker" data-date-autoclose="true">
  <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
    </div>
                                                            


 



                                                            </div>

                                      </div>

                                      <div class="col-md-12">
                                                            <div class="mb-3">
                                                                <label for="verticalnav-address-input">Reason</label>
                                                                <textarea id="verticalnav-address-input" class="form-control" rows="2" name="Reason"><?php echo e(old('Reason')); ?></textarea>
                                                            </div>
                                                        </div>
</div>
                                               
                                               
                                               
                                               
                                            

                                            
                                            

                                            <div><button type="submit" class="btn btn-success w-lg float-right">Save </button>
                                                 <a href="<?php echo e(URL('/')); ?>" class="btn btn-secondary w-lg float-right">Cancel</a>
                                            </div>
                                            

                                        </form>

 
                                    </div>
                                </div>
                                <!-- end card -->

                                 <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Leave List</h4>
                                          

                                   

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->



                                


                        <div class="row">
                            <div class="col-md-12">
                                 <div class="card">
                                     <div class="card-body p-4">
                                         <table id="datatable" class="table   dt-responsive  nowrap w-100 table-sm">
                                            <thead>
                                            <tr>
                                                
                                                <th>Leave Type</th>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>No of Days</th>
                                                <th>Reason</th>
                                                <th>OM</th>
                                                <th>HR</th>
                                                <th>GM</th>
                                                
                                                
                                                <th>Action</th>
                                           
                                                
                                             </tr>
                                            </thead>
        
        
                                            <tbody>
                                             
                                            </tbody>
                                        </table>
                                     </div>
                                 </div>
        
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->



                            </div>
                            <!-- end col -->
                         
                         <!-- employee detail side bar -->
                         <?php echo $__env->make('template.emp_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>

<script type="text/javascript">
$(document).ready(function() {

     

     $('#datatable').DataTable({
        "processing": true,
        "serverSide": true,
        "pageLength":50,
        "ajax": "<?php echo e(url('ajax_leave')); ?>",
        "columns":[
           
            { "data": "LeaveTypeName" },
            { "data": "FromDate" },
            { "data": "ToDate" },
            { "data": "NoOfDays" },
            { "data": "Reason" },
            { "data": "OMStatus" },
            { "data": "HRStatus" },
            { "data": "GMStatus" },
            
             
            
           
        
            { "data": "action" }
        ]
     
     });
});

$("#success-alert").fadeTo(4000, 500).slideUp(100, function(){
    // $("#success-alert").slideUp(500);
    $("#success-alert").alert('close');
});


</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/emp/leave.blade.php ENDPATH**/ ?>
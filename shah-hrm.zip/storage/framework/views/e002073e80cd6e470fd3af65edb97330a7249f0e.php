
<?php $__env->startSection('title', 'HR'); ?>
<?php $__env->startSection('content'); ?>
 <div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Desposit ADD</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row">
                <div class="col-xl-12">
                    <?php if(session('error')): ?>
                    <div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                        <strong><?php echo e(Session::get('error')); ?> </strong>
                    </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?> 
                    <div>
                        <div class="alert alert-danger pt-3 pl-0 border-3 bg-danger text-white">
                            <p class="font-weight-bold"> There were some problems with your input.</p>
                            <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="card ">
                        <div class="card-body">
                            <h4 class="card-title mb-4"></h4>
                                <form action="<?php echo e(URL('/FCBAdd')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">Branch*</label>
                                                <select name="BranchID" id="BranchID" class="form-select">
                                                    <option value="">--Select Branch--</option>
                                                    <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value->BranchID); ?>" <?php echo e((@$branch_id== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                          <div class="mb-3">
                                            <label for="basicpill-firstname-input">Employee*</label>
                                            <select name="EmployeeID" id="EmployeeID" class="form-select select2">
                                             <option value="">Select</option>
                                              <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <option value="<?php echo e($value->EmployeeID); ?>" <?php echo e((old('EmployeeID')== $value->EmployeeID) ? 'selected=selected': ''); ?>><?php echo e($value->FirstName); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                           </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">ID*</label>
                                                <input type="text" class="form-control" name="ID" value="<?php echo e(old('ID')); ?> ">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">FTD Amount*</label>
                                                <input type="text" class="form-control" name="FTDAmount" value="<?php echo e(old('FTDAmount')); ?> ">
                                            </div>
                                         </div>
                                         <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">Date*</label>
                                                <div class="input-group" id="datepicker2">
                                                    <input type="text" name="Date"  value="<?php echo e(old('Date')); ?>" autocomplete="off" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true">
                                                    <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">Compliant *</label>
                                                <select name="Compliant" id="Compliant" class="form-select">
                                                    <option value="">Select</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                    <option value="WithD">WD</option>
                                                </select>
                                           </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">KYC Sent*</label>
                                                <select name="KYCSent" id="KYCSent" class="form-select">
                                                    <option value="">Select</option>
                                                    <option value="Yes">Yes</option>
                                                    <option value="No">No</option>
                                                </select>
                                           </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">Dialer</label>
                                                <input type="text" class="form-control" name="Dialer" value="<?php echo e(old('Dialer')); ?> ">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label for="basicpill-firstname-input">Remarks</label>
                                                <input type="text" class="form-control" name="Remarks" value="<?php echo e(old('Remarks')); ?> ">
                                            </div>
                                        </div>
                                    </div>
                                    <div align="right">
                                        <button type="submit" class="btn btn-success w-lg float-right">Save</button>
                                    </div>
                                </form>
                        </div>
                        <!-- end card body -->
                    </div> 

                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->  
        </div> <!-- container-fluid -->
    </div>

    <script type="text/javascript">
     $(document).ready(function(){

        $(document.body).on('change','#BranchID',function(){
            var branch_id = $(this).val();
            $.ajax({
            url:'<?php echo e(url("/getBranchWiseEmployees")); ?>',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            method:"GET",
            data:{branch_id:branch_id},
            dataType:"JSON",
            success:function(data)
            {
                $('#EmployeeID').empty();
                if(data)
                {
                    $('#EmployeeID').append('<option value="">--Select Agent--</option>');
                    var full_name;
                    $.each(data, function(key, value)
                    {
                      if(value.FirstName && !value.MiddleName && value.LastName){
                        full_name = value.FirstName+'&nbsp;'+value.LastName;
                      }
                      else if(value.FirstName && value.MiddleName && !value.LastName){
                        full_name = value.FirstName+'&nbsp;'+value.MiddleName;
                      }
                      else if(value.FirstName && !value.MiddleName && !value.LastName){
                        full_name = value.FirstName;
                      }
                      else{
                        full_name = value.FirstName+'&nbsp;'+value.MiddleName+'&nbsp;'+value.LastName;
                      }
                      $('#EmployeeID').append('<option value="'+ value.EmployeeID +'">'+ full_name +'</option>');
                    })
                }
                
            }
        });
            
        });
     });
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/fcb_add.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script type="text/javascript">

           

         function view_data(id)
    {
 window.open("<?php echo e(URL('/EmployeeDetail')); ?>/"+id,"_self"); 
//alert(id);
    }  

     function edit_data(id)
    {
 window.open("<?php echo e(URL('/edit_customer')); ?>/"+id,"_self"); 
//alert(id);
    }

    function del_data(id)
    {

        var txt;
var r = confirm("Do you want to delete");
if (r == true) {
   window.open("<?php echo e(URL('/LeaveDelete')); ?>/ "+id,"_self");  
} else {
  txt = "You pressed Cancel!";
}



//alert(id);
    }

        </script>
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/StaffDashboard')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 " id="success-alert">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('staff.staff_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                             <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Apply for Leave
                                        <span  style="float: right;" class="text-success btn btn-light btn-outline-success rounded-pill "><?php echo e(Session::get('Months')); ?> Months since you have joined us.</span>
                                    </div>
                                    <div class="card-body">

                                        <form action="<?php echo e(URL('/StaffLeaveSave')); ?>" method="post"> 
                                            <?php echo csrf_field(); ?>





<div class="col-md-4">
<div class="mb-3">
<label for="basicpill-firstname-input">Leave Type</label>
 <select name="LeaveTypeID" id="LeaveTypeID" class="form-select" required="">
<option value="">Select</option>
 <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($value->LeaveTypeID); ?>"  <?php echo e((old('LeaveTypeID')== $value->LeaveTypeID) ? 'selected=selected': ''); ?> ><?php echo e($value->LeaveTypeName); ?></option>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</select>
</div>
</div>



<div id="result" class="col-md-4" >...</div>

 <div class="col-md-4 d-none">
 <div class="mb-3">
    <label for="basicpill-firstname-input">Branch </label>
     <select name="BranchID" id="BranchID" class="form-select">

     <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($value->BranchID); ?>" <?php echo e((old('BranchID')== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
 
  </select>
  </div>
   </div>


 
   
       <div class="col-md-4 d-none">
    <div class="mb-3">
       <label for="basicpill-firstname-input">Employee Name*</label>
        <select name="EmployeeID" id="EmployeeID" class="form-select">

<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <option value="<?php echo e($value->EmployeeID); ?>" <?php echo e((old('EmployeeID')== $value->EmployeeID) ? 'selected=selected': ''); ?>><?php echo e($value->FirstName); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </select>
     </div>
      </div>
   
                                               
<div class="row">
 


<div class="col-md-4">
      <div class="mb-4">
<label>Select Date </label>

<div class="input-daterange input-group" id="datepicker6" data-date-format="dd/mm/yyyy" data-date-autoclose="true" data-provide="datepicker" data-date-container="#datepicker6" >
    <input type="text" class="form-control" name="FromDate" id="FromDate" placeholder="Start Date" value="<?php echo e(old('FromDate') ? old('FromDate') : date('d/m/Y')); ?>" required=""  >
    <input type="text" class="form-control" name="ToDate" id="ToDate" placeholder="End Date" value="<?php echo e(old('ToDate') ? old('ToDate') : date('d/m/Y')); ?>" required="">
</div>
</div>

</div>
 


 

 


 
                                 

<div class="row">
  <div class="col-md-2"><div class="mb-3">
<label class="form-label">Time From </label>

<div class="input-group" id="timepicker-input-group2">
<input  name="FromTime"  id="timepicker2" type="text" class="form-control" data-provide="timepicker" value="<?php echo e(old('FromTime')); ?>">

 </div>
</div></div>
  <div class="col-md-2"><div>
<label class="form-label">To Time</label>

<div class="input-group" id="timepicker-input-group2-to">
<input  name="ToTime"  id="timepicker2_to" type="text" class="form-control" data-provide="timepicker" value="<?php echo e(old('ToTime')); ?>">

 </div>
</div></div>
</div>

 
</script>

<div class="col-md-4">
        <div class="mb-3">
            <label for="verticalnav-address-input">Reason</label>
            <textarea id="verticalnav-address-input" class="form-control" rows="2" name="Reason" required=""><?php echo e(old('Reason')); ?></textarea>
                                                            </div>
                                                        </div>
</div>
                                               
                                               
                                               
                                               
                                       

                                            
                                            

                                            <div><button type="submit" class="btn btn-success w-lg float-right" disabled="">Save </button>
                                                 <a href="<?php echo e(URL('/StaffLeave')); ?>" class="btn btn-secondary w-lg float-right">Cancel</a>
                                            </div>
                                            

                                        </form>

 
                                    </div>
                                </div>
                                <!-- end card -->

                                 <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Leave List</h4>
                                          

                                   

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->



    <?php 

$v_leave = DB::table('v_leave')->get();
     ?>                            


                        <div class="row">
                            <div class="col-md-12">
                                 <div class="card">
                                     <div class="card-body p-4">
                                    <table  class="table table-striped table-sm">
                                            <thead>
                                            <tr>
                                                
                                                <th>Leave Type</th>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>No of Days</th>
                                                <th>Time From</th>
                                                <th>To</th>
                                                <th>Reason</th>
                                                <th>OM</th>
                                                <th>HR</th>
                                                <th>GM</th>
                                                
                                                
                                                <th>Action</th>
                                           
                                                
                                             </tr>
                                            </thead>

<?php $__currentLoopData = $v_leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e($value->LeaveTypeName); ?></td>
                                                <td><?php echo e($value->FromDate); ?></td>
                                                <td><?php echo e($value->ToDate); ?></td>
                                                <td><?php echo e($value->NoOfDays); ?></td>
                                                <td><?php echo e($value->FromTime); ?></td>
                                                <td><?php echo e($value->ToTime); ?></td>
                                                <td><?php echo e($value->Reason); ?></td>
                                                <td class="<?php echo e(($value->OMStatus!='Approved') ? 'text-danger' : 'text-success'); ?>" ><?php echo e($value->OMStatus); ?></td>
                                                <td class="<?php echo e(($value->HRStatus!='Approved') ? 'text-danger' : 'text-success'); ?>"><?php echo e($value->HRStatus); ?></td>
                                                <td class="<?php echo e(($value->GMStatus!='Approved') ? 'text-danger' : 'text-success'); ?>"><?php echo e($value->GMStatus); ?></td>
                                                 <td><a href="javascript:void(0)" onclick="delete_confirm2(`StaffLeaveDelete`,'<?php echo e($value->LeaveID); ?>')" class="dropdown-item">  Delete</a></td>
                                            </tr>

        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                                            <tbody>
                                             
                                            </tbody>
                                        </table>
                                       
                                     </div>
                                 </div>
        
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->



                            </div>
                            <!-- end col -->
                         
                         <!-- employee detail side bar -->
 
                           
                        </div>
                        <!-- end row -->

                      
 

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


<script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>

<script type="text/javascript">
 

$("#success-alert").fadeTo(4000, 500).slideUp(100, function(){
    // $("#success-alert").slideUp(500);
    $("#success-alert").alert('close');
});



    $("#LeaveTypeID").change(function(){
      // alert($('#EmployeeID').val());
       // alert(<?php echo e(Session::token()); ?>);

      var LeaveTypeID = $('#LeaveTypeID').val();
      var EmployeeID = $('#EmployeeID').val();



          console.log(LeaveTypeID);
        
        
            $.ajax({
              url: "<?php echo e(URL('/ajax_leave_validate')); ?>/"+LeaveTypeID+"/"+EmployeeID,
              type: "GET",
              data: {
                  // _token: 43DeWyo3MzTaTYdg5iqACJ2nPyPwCa7NZO9KClYa,
                  "_token": "<?php echo e(csrf_token()); ?>",
                    LeaveTypeID: LeaveTypeID,
                    EmployeeID: EmployeeID,
              },
              cache: false,
              success: function(data){
            
                  // alert(data);
                    $('#result').html('<div class="spinner-border text-primary m-1" role="status"><span class="sr-only">Loading...</span>                  </div>');


                    $('#result').html(data);
                     if($('#allow').val()==0)
                     {
                        $(':input[type="submit"]').prop('disabled', true);    
                     }
                     else
                     {
                        $(':input[type="submit"]').prop('disabled', false);
                     }
            
                    
              }
          });
       
  });


 $( document ).ready(function() {
    



      var LeaveTypeID = $('#LeaveTypeID').val();
      var EmployeeID = $('#EmployeeID').val();



          console.log(LeaveTypeID);
        
        
            $.ajax({
              url: "<?php echo e(URL('/ajax_leave_validate')); ?>/"+LeaveTypeID+"/"+EmployeeID,
              type: "GET",
              data: {
                  // _token: 43DeWyo3MzTaTYdg5iqACJ2nPyPwCa7NZO9KClYa,
                  "_token": "<?php echo e(csrf_token()); ?>",
                    LeaveTypeID: LeaveTypeID,
                    EmployeeID: EmployeeID,
              },
              cache: false,
              success: function(data){
            
                  // alert(data);
                    $('#result').html('<div class="spinner-border text-primary m-1" role="status"><span class="sr-only">Loading...</span>                  </div>');


                    $('#result').html(data);
                     if($('#allow').val()==0)
                     {
                        $(':input[type="submit"]').prop('disabled', true);    
                     }
                     else
                     {
                        $(':input[type="submit"]').prop('disabled', false);
                     }
            
                    
              }
          });

 });

 
</script>
 

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.staff_tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_leave.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
<!-- 
                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a> -->
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 ">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('staff.staff_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- 
                             <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Offical Details
                                    </div>
                                    <div class="card-body">

                                        dddd

 
                                    </div>
                                </div> -->
                                <!-- end card -->


                                 <div class="card">
                                                            <div class="card-header bg-transparent border-bottom h5">
                                                                  Personal Information
                                                              </div>
                                                              <div class="card-body">
                                                                <!-- start of personal detail row -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-sm table-responsive">
  <tr>
    <td class="fw-bold col-md-3">Branch</td>
    <td  class="col-md-6"><?php echo e($employee[0]->BranchName); ?></td>
   
  </tr>
  <tr>
    <td class="fw-bold">Title</td>
    <td><?php echo e($employee[0]->Title); ?></td>
  </tr>
   <tr>
    <td class="fw-bold">First Name</td>
    <td><?php echo e($employee[0]->FirstName); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Middle Name</td>
    <td><?php echo e($employee[0]->MiddleName); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Last Name</td>
    <td><?php echo e($employee[0]->LastName); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Date of Birth</td>
    <td><?php echo e(dateformatman($employee[0]->DateOfBirth)); ?></td>
  </tr>
  <tr>
     <td class="fw-bold">Is Supervisor</td>
    <td>Yes</td>
  </tr>
  <tr>
      <td class="fw-bold">Gender</td>
      <td><?php echo e($employee[0]->Gender); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Email</td>
      <td><?php echo e($employee[0]->Email); ?></td>
  </tr>
   <tr>
      <td class="fw-bold">Password</td>
      <td class="text-success"><?php echo e($employee[0]->Password); ?></td>
  </tr>
   <tr>
      <td class="fw-bold">Nationality</td>
      <td><?php echo e($employee[0]->Nationality); ?></td>
  </tr>
    <tr >
      <td class="fw-bold">Mobile No</td>
      <td><?php echo e($employee[0]->MobileNo); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Home Phone</td>
      <td><?php echo e($employee[0]->HomePhone); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Full Address</td>
      <td><?php echo e($employee[0]->FullAddress); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Education Level</td>
      <td><?php echo e($employee[0]->EducationLevel); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Last Degree</td>
      <td><?php echo e($employee[0]->LastDegree); ?></td>
  </tr>
  
</table>

                                                                <div class="row">
                                                                

                                       
                                        
 
                                     

                                       
                                                                </div>
                                                                <!-- end of personal detail row -->
                                                              </div>
                                                          </div>
                                

                                    <div class="card">
                                       <div class="card-header bg-transparent border-bottom h5">
                                             Marital Detail
                                        </div>
                                      <div class="card-body">

  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-sm table-responsive">
  <tr>
    <td class="fw-bold col-md-3">Marital Status</td>
    <td  class="col-md-6"><?php echo e($employee[0]->MaritalStatus); ?></td>
   
  </tr>
  <tr>
    <td class="fw-bold">SSNorGID</td>
    <td><?php echo e($employee[0]->SSNorGID); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Spouse Name</td>
    <td><?php echo e($employee[0]->SpouseName); ?></td>
  </tr>
 
 
 
  <tr>
      <td class="fw-bold">Spouse Employer</td>
      <td><?php echo e($employee[0]->SpouseEmployer); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Spouse Work Phone</td>
      <td><?php echo e($employee[0]->SpouseWorkPhone); ?></td>
  </tr>
 
  
</table>
                                    
                                         </div>
                                   </div>
                                                                                   


                                     <div class="card">
                                                                     <div class="card-header bg-transparent border-bottom h5">
                                                                           Visa / Passport Section
                                                                       </div>
                                                                       <div class="card-body">

  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-sm table-responsive">
  <tr>
    <td class="fw-bold col-md-3">Visa Issue Date</td>
    <td class="col-md-6" ><?php echo e(dateformatman($employee[0]->VisaIssueDate)); ?></td>
   
  </tr>
  <tr>
    <td class="fw-bold">Visa Expiry Date</td>
    <td><?php echo e(dateformatman($employee[0]->VisaExpiryDate)); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Passpor tNo</td>
    <td><?php echo e($employee[0]->PassportNo); ?></td>
  </tr>
 
 
 
  <tr>
      <td class="fw-bold">Passport Expiry</td>
      <td><?php echo e(dateformatman($employee[0]->PassportExpiry)); ?></td>
  </tr>
    <tr>
      <td class="fw-bold">Eid No</td>
      <td><?php echo e($employee[0]->EidNo); ?></td>
  </tr>
     <tr>
      <td class="fw-bold">Eid Expiry</td>
      <td><?php echo e(dateformatman($employee[0]->EidExpiry)); ?></td>
  </tr>
 
  
</table>


                                                                      
                                                                       </div>
                                                                   </div>
                                                                     



  <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5">
                                        Next of Kin 
                                    </div>
                                    <div class="card-body">

                                         <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-sm table-responsive">
  <tr>
    <td class="fw-bold col-md-3">Next of Kin Name</td>
    <td  class="col-md-6"><?php echo e($employee[0]->NextofKinName); ?></td>
   
  </tr>
  <tr>
    <td class="fw-bold">Next of Kin Address</td>
    <td><?php echo e($employee[0]->NextofKinAddress); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Next of Kin Phone</td>
    <td><?php echo e($employee[0]->NextofKinPhone); ?></td>
  </tr>
 
 
 
  <tr>
      <td class="fw-bold">Next of Kin Relationship</td>
      <td><?php echo e($employee[0]->NextofKinRelationship); ?></td>
  </tr>
 
 
  
</table>




                                      
                                    </div>
                                </div>




  <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Offical Details
                                    </div>
                                    <div class="card-body">

                                        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-sm table-responsive">
  <tr>
    <td class="fw-bold col-md-3">Job Title</td>
    <td class="col-md-6"><?php echo e($employee[0]->JobTitleName); ?></td>
   
  </tr>
  <tr>
    <td class="fw-bold">Department</td>
    <td><?php echo e($employee[0]->DepartmentName); ?></td>
  </tr>
  <tr>
    <td class="fw-bold">Supervisor</td>
    <td><?php echo e(supervisor_name($employee[0]->SupervisorID)); ?></td>
  </tr>
 
 
 
  <tr>
      <td class="fw-bold">Work Location</td>
      <td><?php echo e($employee[0]->WorkLocation); ?></td>
  </tr>
  <tr>
      <td class="fw-bold">Email Offical</td>
      <td><?php echo e($employee[0]->EmailOffical); ?></td>
  </tr>
   <tr>
      <td class="fw-bold">Work Phone</td>
      <td><?php echo e($employee[0]->WorkPhone); ?></td>
  </tr>
   <tr>
      <td class="fw-bold">StartDate</td>
      <td><?php echo e(dateformatman($employee[0]->StartDate)); ?></td>
  </tr>  
  <tr>
      <td class="fw-bold">Salary</td>
      <td><?php echo e($employee[0]->Salary); ?></td>
  </tr>
  <tr>
      <td class="fw-bold">Comisison (If Any)</td>
      <td><?php echo e($employee[0]->ExtraComission); ?></td>
  </tr>
  <tr>
      <td class="fw-bold">Salary Remarks (If Any)</td>
      <td><?php echo e($employee[0]->SalaryRemarks); ?></td>
  </tr>
 
 
  
</table>

 
                                    </div>
                                </div>

                        
                                <!-- end card -->


                           
                                
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                       </form>
                                <!-- end card -->
                            </div>
                            <!-- end col -->
                         
                    
                        

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.staff_tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_dashboard.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'HR'); ?>
 

<?php $__env->startSection('content'); ?>
 
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Document Category</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>

                                        <form action="<?php echo e(URL('/DocumentCategorySave')); ?>" method="post" enctype="multipart/form-data">

                                         <?php echo e(csrf_field()); ?> 

                                         <div class="row">
                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Document Type *</label>
                                         <input type="text" class="form-control" name="DocumentCategoryName" value="<?php echo e(old('DocumentCategoryName')); ?> ">
                                         </div>
                                         </div>
                                         

                                        

                                         	<div><button type="submit" class="btn btn-success w-lg float-right">Save</button>
                                         	     
                                         	</div>
                                         	
                                         
                                         </div>
                                         
                                     
                                         
                                         
                                         
                                         
                                         
                                         

                                     </form>

                                        
                                    </div>
                                    <!-- end card body -->
                                </div> 

                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4">List of document types</h4>


                                               <?php if(count($document_category) >0): ?> 
                                        <div class="table-responsive">
                                            <table class="table table-sm table-striped align-middle table-nowrap mb-0">
                                                <tbody>
                                                    <thead>
                                                    <th scope="col" >S.No</th>
                                                    <th scope="col">Document Types</th>
                                                    
                                                    <th scope="col">Action</th>
                                                  </thead>
                                                </tbody><tbody>
                                               <?php $i=1; ?>
                                               <?php $__currentLoopData = $document_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="col-md-1"><?php echo e($i); ?>.</td>
                                                         
                                                        <td class="col-md-10">
                                                            <?php echo e($value->DocumentCategoryName); ?>

                                                             
                                                         
                                                        <td class="col-md-1"><a href="<?php echo e(URL('/DocumentCategoryEdit/'.$value->DocumentCategoryID)); ?>"><i class="bx bx-pencil align-middle me-1"></i></a> <a href="<?php echo e(URL('/DocumentCategoryDelete/'.$value->DocumentCategoryID)); ?>"><i class="bx bx-trash  align-middle me-1"></i></a></td>
                                                        <td>
                                                            
                                                        </td>
                                                    </tr>
                                                   <?php $i++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     

                                                   
                                                </tbody>
                                            </table>
                                            
                                              
                                        </div>
                                        <?php endif; ?>

                                          <?php if(count($document_category) ==0): ?> 
                                        <p class="text-danger h6">No record to display</p>

                                        <?php endif; ?>
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/document_category.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Users'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

 <div class="page-content">
<div class="container-fluid">

 <!-- start page title -->
<div class="row">
<div class="col-12">
<div class="page-title-box d-sm-flex align-items-center justify-content-between">
 <h4 class="mb-sm-0 font-size-18">Manage Users</h4>

 <div class="page-title-right">
<div class="page-title-right">

</div>
</div>
</div>
</div>
<div>
 <!-- end page title -->

 <?php if(session('error')): ?>

 <div class="alert alert-<?php echo e(Session::get('class')); ?> p-3" id="success-alert">
                    
                   <?php echo e(Session::get('error')); ?>  
                </div>

<?php endif; ?>

 <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>
 
            <?php endif; ?>
<div class="row">
 <div class="col-12">
    <form action="<?php echo e(URL('/SaveUser')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

<div class="card">
<div class="card-body">

<h4 class="card-title">Add New User</h4>
<p class="card-title-desc"></p>

 <div class="mb-3 row">
<label for="example-text-input" class="col-md-2 col-form-label">Branch Name</label>
<div class="col-md-10">
<select name="BranchID" class="form-select">
    <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($value->BranchID); ?>"><?php echo e($value->BranchName); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
 </div>



<div class="mb-3 row">
<label for="example-email-input" class="col-md-2 col-form-label">Full Name</label>
<div class="col-md-10">
<input class="form-control" type="text"  value="<?php echo e(old('FullName')); ?>"  name="FullName" id="example-email-input">
</div>
</div>
<div class="mb-3 row">
<label for="example-url-input" class="col-md-2 col-form-label">Username</label>
<div class="col-md-10">
<input class="form-control" type="text"  value="<?php echo e(old('Email')); ?>" name="Email" required>
</div>

</div>
<div class="mb-3 row">
<label for="example-url-input" class="col-md-2 col-form-label">Password</label>
<div class="col-md-10">
<input class="form-control" type="text"  name="Password" value="<?php echo e(old('Password')); ?>" required>
</div>

</div>
<div class="mb-3 row">
<label for="example-tel-input" class="col-md-2 col-form-label">User Type</label>
<div class="col-md-10">
<select name="UserType" class="form-select">

     
      <option value="HR">HR</option>
    <option value="OM">OM</option>
    <option value="GM">GM</option>
    


</select> </div>
 </div>
 
 <div class="mb-3 row">
<label for="example-tel-input" class="col-md-2 col-form-label">Active</label>
<div class="col-md-10">
<select name="Active" class="form-select">

     
    <option value="Y">Yes</option>
    <option value="N">No</option>
    


</select> </div>
 </div>

 
                                      
    <input type="submit" class="btn btn-primary w-md">                                   
                                   
    
                                      
                                        

                                       

                                    </div>
                                </div>

                            </form>
                            </div> <!-- end col -->
                        </div>
                      

  <div class="row">
      <div class="col-lg-12">
          
          <div class="card">
              
          <div class="card-body">
            <h4 class="card-title pb-3">Manage Users</h4>
             <!-- <p class="card-title-desc"> Add <code>.table-sm</code> to make tables more compact by cutting cell padding in half.</p>  -->   
                                        
       <div class="table-responsive">
        <table class="table table-sm m-0" id="datatable">
            <thead>
               <tr>
                <th>#</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Password</th>
                <th>User Type</th>
                <th>Created on</th>
                <th>User's Branch</th>
                
                <th>Active</th>
                <th>Action</th>
              </tr>
             </thead>
            <tbody>
 


                   <?php $no=1; ?> 
                <?php $__currentLoopData = $v_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
     <td  ><?php echo e($no++); ?></td>
                <td scope="row"><?php echo e($value->FullName); ?></td>
                <td><?php echo e($value->Email); ?></td>
                <td>*********</td>
                <td><?php echo e($value->UserType); ?></td>
                <td><?php echo e($value->eDate); ?></td>
                <td><?php echo e($value->BranchName); ?></td>
                
                <td><?php echo e($value->Active); ?></td>
                <td><div class="d-flex gap-1">
        <a href="<?php echo e(URL('/EditUser/'.$value->UserID)); ?>" class="text-secondary"><i class="mdi mdi-pencil font-size-15"></i></a>
        <a href="<?php echo e(URL('/DeleteUser/'.$value->UserID)); ?>"  class="text-secondary"><i class="mdi mdi-delete font-size-15"></i></a>
        <a href="<?php echo e(URL('/checkUserRole/'.$value->UserID)); ?>"  class="text-secondary"><i class="fas fa-user-lock
 font-size-12"></i></a>
                                                             </div> </td>
                 
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              </tbody>
               </table>
        
                  </div>
        
                   </div>
          </div>
      </div>



  </div>                     
 
                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


    
</div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/users.blade.php ENDPATH**/ ?>
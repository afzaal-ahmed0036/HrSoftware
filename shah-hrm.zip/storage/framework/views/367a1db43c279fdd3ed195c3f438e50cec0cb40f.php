

<?php $__env->startSection('title', 'HR'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Desposite</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                    <strong>Active : </strong>     <?php echo e(session::get('FCBMonthName')); ?>

                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

            
                                <div class="card ">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>

                                        <form action="<?php echo e(URL('/FCBSave')); ?>" method="post"  >

                                         <?php echo e(csrf_field()); ?> 

                                         <div class="row">
                                           <div class="col-md-1">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">ID*</label>
                                         <input type="text" class="form-control" name="ID" value="<?php echo e(old('ID')); ?> ">
                                         </div>
                                         </div>


                                                 
                                                     
                                                     


                                                     
                                                         <div class="col-md-4">
                                                      <div class="mb-3">
                                                         <label for="basicpill-firstname-input">Employee*</label>
                                                          <select name="EmployeeID" id="EmployeeID" class="form-select select2">
                                                         <option value="">Select</option>

                                                          <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                           <option value="<?php echo e($value->EmployeeID); ?>" <?php echo e((old('EmployeeID')== $value->EmployeeID) ? 'selected=selected': ''); ?>><?php echo e($value->FirstName); ?> <?php echo e($value->MiddleName); ?> <?php echo e($value->LastName); ?></option>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                         
                                                     
                                                       </select>
                                                       </div>
                                                        </div>
                                                     
                                                     
                                                     
                                                                
                                         
                                                       <div class="col-md-2">
                                                     <div class="mb-3">
                                                     <label for="basicpill-firstname-input">FTD Amount USD *</label>
                                                     <input type="text" class="form-control" name="FTDAmount" value="<?php echo e(old('FTDAmount')); ?> ">
                                                     </div>
                                                     </div>
                                                     
                                                    
                                                       <div class="col-md-2">
                                                     <div class="mb-3">
                                                     <label for="basicpill-firstname-input">Date*</label>
                                                     <div class="input-group" id="datepicker2">
  <input type="text" name="Date"  value="<?php echo e(date('d/m/Y')); ?>" autocomplete="off" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true"  >
  <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
    </div>
                                                     </div>
                                                     </div>
                                                     



                                                      
                                                      

                                                         <div class="col-md-2">
                                                      <div class="mb-3">
                                                         <label for="basicpill-firstname-input">Compliant *</label>
                                                          <select name="Compliant" id="Compliant" class="form-select">
                                                         <option value="">Select</option>
                                                         <option value="Yes">Yes</option>
                                                         <option value="No">No</option>
                                                         <option value="WithD">WD</option>
                                                    
                                                       </select>
                                                       </div>
                                                        </div>
                                                     

                                                      
                                                     
                                                         <div class="col-md-2">
                                                      <div class="mb-3">
                                                         <label for="basicpill-firstname-input">KYC Sent*</label>
                                                          <select name="KYCSent" id="KYCSent" class="form-select">
                                                         <option value="">Select</option>
                                                         <option value="Yes">Yes</option>
                                                         <option value="No">No</option>
                                                    
                                                       </select>
                                                       </div>
                                                        </div>
                                                     
                                                     
                                                     

                                                      <div class="col-md-1">
                                                     <div class="mb-3">
                                                     <label for="basicpill-firstname-input">Dialer</label>
                                                     <input type="text" class="form-control" name="Dialer" value="<?php echo e(old('Dialer')); ?> ">
                                                     </div>
                                                     </div>
                                                     
                                                     
                                                    

                                                  
                                                      <div class="col-md-4">
                                                   <div class="mb-3">
                                                      <label for="basicpill-firstname-input">Branch*</label>
                                                       <select name="BranchID" id="BranchID" class="form-select">
                                                      
                                                       <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value->BranchID); ?>" <?php echo e((old('BranchID')== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      
                                                     </select>
                                                    </div>
                                                     </div>
                                                  
                                                  
                                                  
                                                    <div class="col-md-4">
                                                  <div class="mb-3">
                                                  <label for="basicpill-firstname-input">Remarks</label>
                                                  <input type="text" class="form-control" name="Remarks" value="<?php echo e(old('Remarks')); ?> ">
                                                  </div>
                                                  </div>
                                                  
                                                  
                                                  
                                                      
                                                      
                                                      
                                                            

                                        

                                          <div><button type="submit" class="btn btn-success w-lg float-right">Save</button>
                                               
                                          </div>
                                          
                                         
                                         </div>
                                         
                                     
                                         
                                         
                                         
                                         
                                         
                                         

                                     </form>

                                        
                                    </div>
                                    <!-- end card body -->
                                </div> 

                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4">FCB Desposite</h4>


 <?php if(count($fcb) >0): ?> 
  <table id="datatable" class="table table-bordered table-sm dt-responsive nowrap w-100 dataTable no-footer dtr-inline" role="grid" aria-describedby="datatable_info" style="width: 1247px;" data-page-length='50'>
                                            <thead>
                                            <tr role="row" >
                                             <th scope="col" >S.No</th>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Agent</th>
                                                    <th scope="col">FTD Amount</th>
                                                    <th scope="col">Date</th>
                                                    <th scope="col">Compliant</th>
                                                    <th scope="col">KYC Sent</th>
                                                    <th scope="col">Dialer</th>
                                                    
                                                    <th scope="col">Action</th>
                                            </tr>
                                            </thead>
        
        
                                            <tbody>
                                         <?php $i=1; ?>
                                               <?php $__currentLoopData = $fcb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                            
                                            <tr  >
                                               <td ><?php echo e($i); ?>.</td>
                                                <td  ><?php echo e($value->ID); ?></td>
                                                <td  ><?php echo e($value->FirstName); ?> <?php echo e($value->MiddleName); ?> <?php echo e($value->LastName); ?></td>
                                                        <td ><?php echo e(number_format($value->FTDAmount,2)); ?></td>
                                                        <td ><?php echo e($value->Date); ?></td>
                                                        <td ><?php echo e($value->Compliant); ?></td>
                                                        <td ><?php echo e($value->KYCSent); ?></td>
                                                        <td ><?php echo e($value->Dialer); ?></td>
                                                <td><center><a href="<?php echo e(URL('/FCBEdit/'.$value->FCBID)); ?>"><i class="bx bx-pencil align-middle me-1"></i></a> <a href="#" onclick="delete_confirm2('FCBDelete',<?php echo e($value->FCBID); ?>)"><i class="bx bx-trash  align-middle me-1"></i></a></center></td>
                                             </tr>
                                                <?php $i++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </tbody>
                                        </table>

 <?php endif; ?>

                                          <?php if(count($fcb) ==0): ?> 
                                        <p class="text-danger h6">No record to display</p>

                                        <?php endif; ?>

                                              
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/fcb.blade.php ENDPATH**/ ?>
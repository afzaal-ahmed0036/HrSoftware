<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <?php echo e(env('APP_COPYRIGHT')); ?>

                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </footer><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/template/footer.blade.php ENDPATH**/ ?>
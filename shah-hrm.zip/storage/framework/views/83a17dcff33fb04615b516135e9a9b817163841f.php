

<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-9">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 ">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('emp.emp_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                             <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Loan / Installments
                                    </div>
                                    <div class="card-body">

                                         <?php if(count($loan)>0): ?>    
                                        <table class="table table-sm align-middle table-nowrap mb-0">
                                        <tbody><tr>
                                        <th scope="col">S.No</th>
                                        <th scope="col">Loan</th>
                                        <th scope="col">Remarks</th>
                                        <th scope="col">Delete</th>
                                        </tr>
                                        </tbody>
                                        <tbody>
                                        <?php $__currentLoopData = $loan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr class="bg-light">
                                         <td class="col-md-1"><?php echo e($key+1); ?></td>
                                         <td class="col-md-1"><?php echo e($value->Amount); ?></td>
                                         <td class="col-md-1"><?php echo e($value->Remarks); ?></td>
                                         <td class="col-md-1"><a href="<?php echo e(URL('/LoanDelete')); ?>/<?php echo e($value->LoanID); ?>">Delete</a></td>

                                          

                                         </tr>
                                         <tr>
                                           <td colspan="3"> <?php 

                                         $loan_deduction=DB::table('loan_deduction')->where('LoanID',$value->LoanID)->get();

                                          ?>


                                          <?php if(count($loan_deduction)>0): ?>    
                                         <table class="table table-sm align-middle table-nowrap mb-0">
                                         <tbody><tr>
                                         <th scope="col">S.No</th>
                                         <th scope="col">Amount</th>
                                         <th scope="col">Date</th>
                                         <th scope="col">Delete</th>
                                         </tr>
                                         </tbody>
                                         <tbody>
                                         <?php $__currentLoopData = $loan_deduction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                          <td class="col-md-1"><?php echo e($key+1); ?></td>
                                          <td class="col-md-1"><?php echo e($value->Amount); ?></td>
                                          <td class="col-md-1"><?php echo e($value->LoanDeductionDate); ?></td>
                                          <td class="col-md-1"><a href="<?php echo e(URL('/LoanInstallmentDelete')); ?>/<?php echo e($value->LoanDeductionID); ?>">Delete</a></td>
                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                          </tbody>
                                          </table>
                                          <?php else: ?>
                                            <p class=" text-danger">No data found</p>
                                          <?php endif; ?> </td>


                                            
                                           
                                         </tr>

                                         

                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                         </tbody>
                                         </table>
                                         <?php else: ?>
                                           <p class=" text-danger">No data found</p>
                                         <?php endif; ?>   

 
                                    </div>
                                </div>
                                <!-- end card -->



                          
                            <div class="card">
                                                            <div class="card-header bg-transparent border-bottom">
                                                                  <h5>Make Loan</h5>
                                                              </div>
                                                              <div class="card-body">
                                                                <!-- enctype="multipart/form-data" -->
                                                                <form action="<?php echo e(URL('/LoanSave')); ?>" method="post"> 
                                                                <?php echo e(csrf_field()); ?> 

                                                              
                                                                  <div class="row">
                                                                      <div class="col-md-4"> 
                                                                      <label for="basicpill-firstname-input">Request Date </label>
                                                                     <div class="input-group" id="datepicker2">
                                                                   <input autocomplete="off"  type="text" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true" name="RequestDate" required="">
                                                                   <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                                                     </div>
                                                                   </div> 



                                                                     <div class="col-md-4">
                                                                   <div class="mb-3">
                                                                   <label for="basicpill-firstname-input">Loan*</label>
                                                                   <input type="text" class="form-control" name="Amount"  id="Amount"   required="">
                                                                   </div>
                                                                   </div>   
<div class="col-md-4"> 
                                                                      <label for="basicpill-firstname-input">Start Date </label>
                                                                       <div class="input-group" id="datepicker2">

                                                                     <input  autocomplete="off" type="text" name="StartDate" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true"  required="">
                                                                     <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                                                       </div>
                                                                     </div>
                                                                   <div class="col-md-4">
                                                                   <div class="mb-3">
                                                                   <label for="basicpill-firstname-input">No of Installments </label>
                                                                   <input type="text" class="form-control" name="NoOfInstallment" id="NoOfInstallment"  required="">
                                                                   </div>
                                                                   </div>



                                                                    <div class="col-md-4">
                                                                   <div class="mb-3">
                                                                   <label for="basicpill-firstname-input">Installment Per Month </label>
                                                                   <input type="text" class="form-control" name="Installment" id="Installment"  readonly="" required="" >
                                                                   </div>
                                                                   </div>

                                                        <div class="col-md-12">
                                                        <div class="mb-3">
                                                        <label for="verticalnav-address-input">Remarks</label>
                                                        <textarea id="verticalnav-address-input" class="form-control" rows="3" name="Remarks" required=""></textarea>
                                                        </div>
                                                        </div>

                                                                     

                                                                  </div>

                                                                   
                                                                   
                                                              
                                                              <div><button type="submit" class="btn btn-success w-md float-right">Save</button>
                                                                   
                                                              </div>
                                                              




                                                              </form>
                                                              </div>
                                                          </div>
                          
                                
                            </div>
                            <!-- end col -->
                         
                         <!-- employee detail side bar -->
                         <?php echo $__env->make('template.emp_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>
 
<script>
  $(document).ready(function(){
    $('#NoOfInstallment').keyup(calculate);
    
});
function calculate(e)
{
   

  if($('#Amount').val()>0 && $('#NoOfInstallment').val() >0)
  {

    $('#Installment').val($('#Amount').val() / $('#NoOfInstallment').val());
  }
  else
  {
   $('#Installment').val(0); 
  }
}
</script>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/emp/emp_loan.blade.php ENDPATH**/ ?>
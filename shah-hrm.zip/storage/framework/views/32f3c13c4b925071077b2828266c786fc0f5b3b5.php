

<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18"> Salary Detail</h4>

                                    <div class="page-title-right ">
                                        <div class="page-title-right text-danger">
                                         <!-- button will appear here -->[<?php echo e(session::get('MonthName')); ?>]  <a href="<?php echo e(URL('/SalaryPrint/'.session::get('MonthName').'/'.session::get('BranchID'))); ?>" target="_blank" class="shadow-sm btn btn-success btn-rounded w-sm"><i class="mdi mdi-printer me-2"></i>Print</a>

                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"> </h4>

                                        <table   class="table table-sm table-bordered dt-responsive nowrap w-100 dataTable no-footer dtr-inline" role="grid" aria-describedby="datatable_info" style="width: 1247px;">
                                            <thead>
                                            <tr>
                                            	  <tr class="bg-light ">
                                                    <th scope="col">S.No</th>
                                                    <th scope="col">Employee ID</th>
                                                    <th scope="col">Employee Name</th>
                                                    <th scope="col">Job Title </th>
                                                    <th scope="col">Department</th>
                                                    <th scope="col">Days Present</th>
                                                    <th scope="col">LWPay</th>
                                                    <th scope="col">PerDay</th>
                                                    
                                                    <th scope="col">Basic</th>
                                                    <th scope="col">HRA</th>
                                                    <th scope="col">Transport</th>
                                                    <th scope="col">Other Com</th>
                                                    <th scope="col">Adv Loan</th>
                                                    
                                                    <th scope="col">Leave Ded</th>
                                                    <th scope="col">Total Ded</th>
                                                    
                                                    <th scope="col">Grand Salary</th>
                                                    <th scope="col">Net Salary</th>
                                                     
                                                   


                                            	<th class="col-md-1 d-print-none">Action</th>

                                            </tr>
                                             </thead>
        
        
                                            <tbody>
                                            
                                             
                                            <tr>
                                            	<?php foreach ($salary as $key => $value): ?>
                                            		
                                            	
                                                <td> <?php echo e($key+1); ?> </td>
                                                <td> <?php echo e($value->EmployeeID); ?> </td>
                                                <td> <?php echo e($value->EmployeeName); ?> </td>
                                                 <td> <?php echo e($value->JobTitle); ?> </td>
                                                 <td> <?php echo e($value->Department); ?> </td>
                                                 <td> <?php echo e($value->DaysPresent); ?> </td>
                                                 <td> <?php echo e($value->LWPay); ?> </td>
                                                 <td> <?php echo e($value->PerDay); ?> </td>
                                                 <td> <?php echo e($value->BasicSalary); ?> </td>
                                                 <td> <?php echo e($value->HRA); ?> </td>
                                                 <td> <?php echo e($value->Transport); ?> </td>
                                                 <td> <?php echo e($value->OtherAllowance); ?> </td>
                                                 <td> <?php echo e($value->AdvanceLoan); ?> </td>
                                                 <td> <?php echo e($value->LeaveDeduction); ?> </td>
                                                 <td> <?php echo e($value->TotalDeduction); ?> </td>
                                                 <td> <?php echo e($value->GrandSalary); ?> </td>
                                                 <td> <?php echo e($value->NetSalary); ?> </td>
                                                 

                                                 
                                                 <td class="d-print-none"> <a href="<?php echo e(URL('/SalaryEdit/'.$value->SalaryID)); ?>"  ><i class="bx bx-pencil align-middle me-1"></i></a> <a href="#" onclick="delete_confirm2('SalaryDelete',<?php echo e($value->SalaryID); ?>)"><i class="bx bx-trash  align-middle me-1"></i></a></td>
                                                 
                                            </tr> 

                                            <?php endforeach ?>
                                             

                                           
                                        </tbody>
                                        </table>
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/searchsalary.blade.php ENDPATH**/ ?>
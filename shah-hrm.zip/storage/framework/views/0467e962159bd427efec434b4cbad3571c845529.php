<div class="vertical-menu">
    <div data-simplebar class="h-100">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">

                <li>
                    <a href="<?php echo e(URL('/Dashboard')); ?>" class="waves-effect">
                        <i class="bx bx-home-circle"></i>
                        <span key="t-dashboards">Dashboards</span>
                    </a>
                  
                </li>

                <li>
                    <a href="<?php echo e(URL('/Employee')); ?>" class="waves-effect">
                        <i class="bx bxs-user-plus"></i>
                        <span key="t-calendar">Employee</span>
                    </a>
                </li> 
                
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-plus"></i>
                        <span key="t-ecommerce">Deposit</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/FCBMonth/Input')); ?>" key="t-products">Add Deposit</a></li>
                        <li><a href="<?php echo e(URL('/FCBView/')); ?>" key="t-products">View Deposit</a></li>
                           
                     
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-plus"></i>
                        <span key="t-ecommerce">New Deposit</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/FCBAdd')); ?>" key="t-products">Add Deposit</a></li>
                        <li><a href="<?php echo e(URL('/FCBListing')); ?>" key="t-products">View Deposit</a></li>
                           
                     
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-plus"></i>
                        <span key="t-ecommerce">Live Account</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/LiveAccountAdd')); ?>" key="t-products">Add Live Account</a></li>
                        <li><a href="<?php echo e(URL('/LiveAccountListing')); ?>" key="t-products">View Live Account</a></li>
                           
                     
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-plus"></i>
                        <span key="t-ecommerce">Reports</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/TopAgentReport')); ?>" key="t-products">Top Agent Report</a></li>
                        <li><a href="<?php echo e(URL('/YearlyReport')); ?>" key="t-products">Year Wise Report</a></li>
                        <li><a href="<?php echo e(URL('/QuarterlyReport')); ?>" key="t-products">Quarter Wise Report</a></li>
                        <li><a href="<?php echo e(URL('/TopLiveAccount')); ?>" key="t-products">Top Live Account</a></li>
                    </ul>
                </li>
                


                <li>
                    <a href="<?php echo e(URL('/AttendanceImport')); ?>" class="waves-effect">
                        <i class="mdi mdi-database-import-outline"></i>
                        <span key="t-calendar">Import Attendance</span>
                    </a>
                </li> 

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-dollar-circle"></i>
                        <span key="t-ecommerce">Salary Section</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/Salary')); ?>" key="t-products">Make Salary</a></li>
                        <li><a href="<?php echo e(URL('/ViewSalary')); ?>" key="t-products">Search Salary</a></li>
                        <li><a href="<?php echo e(URL('/EU')); ?>" key="t-products">Operation Manager</a></li>
                          
                     
                    </ul>
                </li>
                
                <li>
                    <a href="<?php echo e(URL('/Document')); ?>" class="waves-effect">
                        <i class="mdi mdi-database-import-outline"></i>
                        <span key="t-calendar">All Documents </span>
                    </a>
                </li> 

                <li>
                    <a href="<?php echo e(URL('/Fleet')); ?>" class="waves-effect">
                        <i class="mdi mdi-car"></i>
                        <span key="t-calendar">Fleet Management </span>
                    </a>
                </li> 

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-hammer-wrench"></i>
                        <span key="t-ecommerce">Setting</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/Branches')); ?>" key="t-products">Branch</a></li>
                        
                        <li><a href="<?php echo e(URL('/DocumentCategory')); ?>" key="t-products">Document Category</a></li>
                         <li><a href="<?php echo e(URL('/Departments')); ?>" key="t-products">Departments</a></li>
                        <li><a href="<?php echo e(URL('/JobTitle')); ?>" key="t-products">Job Title</a></li>
                         <li><a href="<?php echo e(URL('/Letter')); ?>" key="t-products">Letter Templates</a></li>
                         <li><a href="<?php echo e(URL('/Team')); ?>" key="t-products">Team Structure</a></li>
                         <li><a href="<?php echo e(URL('/Users')); ?>" key="t-products">Users</a></li> 
                         <!-- <li><a href="<?php echo e(URL('/Role')); ?>" key="t-products">User Rights & Control</a></li>  -->

                     
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-hammer-wrench"></i>
                        <span key="t-ecommerce">Monthlty Target</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/CurrentTarget')); ?>" key="t-products">Add Target</a></li>
                        <li><a href="<?php echo e(URL('/TargetList')); ?>" key="t-products">View Target</a></li>
                    </ul>
                </li>


             <!--    <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-bar-chart-alt-2"></i>
                        <span key="t-ecommerce">Reports</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(URL('/inventory')); ?>" key="t-products">Inventory</a></li>
                        <li><a href="<?php echo e(URL('/daily_sale')); ?>" key="t-products">Daily Sales</a></li>
                        <li><a href="<?php echo e(URL('/over_ledger')); ?>" key="t-products">Overall Ledger</a></li>
                        <li><a href="<?php echo e(URL('/rep_report')); ?>" key="t-products">Agent Wise Sale</a></li>
                        <li><a href="<?php echo e(URL('/daily_sale')); ?>" key="t-products">Month Wise Sale</a></li>
                        <li><a href="<?php echo e(url('/export/xlsx')); ?>" key="t-products">Alert SMS</a></li>
                        <li><a href="#" key="t-products">Map</a></li>
                        <li><a href="<?php echo e(URL('/daywise_payment_alert')); ?>" key="t-products">Day Wise Payment Alert</a></li>
                        
                     
                    </ul>
                </li> -->

                <li>
                    <a href="<?php echo e(URL('/logout')); ?>" class="waves-effect">
                        <i class="bx bx-power-off"></i>
                        <span key="t-calendar">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/template/sidebar.blade.php ENDPATH**/ ?>
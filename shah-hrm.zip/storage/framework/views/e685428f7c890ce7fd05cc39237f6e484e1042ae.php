  
<a href="<?php echo e(URL('/StaffNoticeBoard')); ?>">go back</a>

<table class="table table-sm align-middle table-nowrap mb-0">
                                        
                                         <tr >
                                         <th style="width: 600px;" > </th>
                                         <th style="width: 10px;" >Status</th>
                                        <th style="width: 10px;" >Date</th>
                                          </tr>
                                        
                                        <tbody>
                                         <?php if(!$notice->isEmpty()): ?>        
                                        <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr valign="top" >
                                          <td ><strong><?php echo e($value->Title); ?></strong></td>
                                         
                                         <td ><span class="badge  <?php echo e(($value->Status=='Draft') ?'badge bg-warning' : 'bg-primary'); ?>"><?php echo e($value->Status); ?></span></td>
                                         <td ><?php echo e(dateformatman($value->Date)); ?></td>
                                      
                                         
                                        
                                         </tr>
                                        <tr>
                                             <td><div style="width: 1000px !important; overflow: auto;" 
                                                ><?php echo   $value->Detail; ?></div></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                          <?php else: ?>
                                           
                                         <tr>
                                             <td colspan="6" class="bg bg-light text-center">
                                           No data found      
                                             </td>
                                         <?php endif; ?>
                                         </tr> 
                                         </tbody>
                                         </table> 
<?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/notice_board_view.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Branches'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Branches</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <strong><?php echo e(Session::get('error')); ?> </strong>
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4"></h4>

                                        <form action="<?php echo e(URL('/BranchSave')); ?>" method="post" enctype="multipart/form-data">

                                         <?php echo e(csrf_field()); ?> 

                                         <div class="row">
                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Branch*</label>
                                         <input type="text" class="form-control" name="BranchName" value="<?php echo e(old('BranchName')); ?> ">
                                         </div>
                                         </div>
                                         

                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Contact*</label>
                                         <input type="text" class="form-control" name="BranchContact" value="<?php echo e(old('BranchContact')); ?> ">
                                         </div>
                                         </div>
                                         
                                         
                                           <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Email*</label>
                                         <input type="text" class="form-control" name="BranchEmail" value="<?php echo e(old('BranchEmail')); ?> ">
                                         </div>
                                         </div>

                                               <div class="col-md-4">
                                         <div class="mb-3">
                                         <label for="basicpill-firstname-input">Address*</label>
                                         <input type="text" class="form-control" name="BranchAddress" value="<?php echo e(old('BranchAddress')); ?> ">
                                         </div>
                                         </div>

                                         <div class="col-md-4">
                                         	<div class="mb-3"><label for="basicpill-firstname-input" class="pr-5">Branch Logo</label><br><input type="file" name="BranchLogo" id="BranchLogo"></div></div>


                                         	<div><button type="submit" class="btn btn-success w-lg float-right">Save</button>
                                         	     
                                         	</div>
                                         	
                                         
                                         </div>
                                         
                                     
                                         
                                         
                                         
                                         
                                         
                                         

                                     </form>

                                        
                                    </div>
                                    <!-- end card body -->
                                </div> 

                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-4">List of Branches</h4>


                                               <?php if(count($branch) >0): ?> 
                                        <div class="table-responsive">
                                            <table class="table align-middle table-nowrap mb-0">
                                                <tbody><tr>
                                                    <th scope="col" >Logo</th>
                                                    <th scope="col">Branch Name</th>
                                                    <th scope="col">Contact</th>
                                                    <th scope="col">Action</th>
                                                  </tr>
                                                </tbody><tbody>
                                               
                                               <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>

                                                        <td style="width: 100px;"><img src="<?php echo e(URL('/uploads/'.$value->BranchLogo)); ?>" alt="" class="avatar-md h-auto d-block rounded"></td>
                                                        <td>
                                                            <h5 class="font-size-13 text-truncate mb-1"><a href="#" class="text-dark"><?php echo e($value->BranchName); ?> </a></h5>
                                                            <p class="text-muted mb-0"><i class="mdi mdi-email-outline align-middle me-1"></i><?php echo e($value->BranchEmail); ?></p>
                                                            <p class="text-muted mb-0"><i class="bx bxs-map align-middle me-1"></i><?php echo e($value->BranchAddress); ?></p>
                                                        </td>
                                                        <td><i class="bx bx-phone align-middle me-1"></i> <?php echo e($value->BranchContact); ?></td>
                                                        <td><a href="<?php echo e(URL('/BranchEdit/'.$value->BranchID)); ?>"><i class="bx bx-pencil align-middle me-1"></i></a> <a href="<?php echo e(URL('/BranchDelete/'.$value->BranchID)); ?>"><i class="bx bx-trash  align-middle me-1"></i></a></td>
                                                        <td>
                                                            
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     

                                                   
                                                </tbody>
                                            </table>
                                            
                                              
                                        </div>
                                        <?php endif; ?>

                                          <?php if(count($branch) ==0): ?> 
                                        <p class="text-danger h6">No record to display</p>

                                        <?php endif; ?>
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/branch.blade.php ENDPATH**/ ?>
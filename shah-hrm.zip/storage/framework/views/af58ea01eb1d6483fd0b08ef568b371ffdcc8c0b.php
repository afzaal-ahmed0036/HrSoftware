

<?php $__env->startSection('title', 'Emplyee Section'); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Employee Detail</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         <a href="<?php echo e(URL('/Employee')); ?>" class="btn btn-success btn-rounded waves-effect waves-light mb-2 me-2"><i class="mdi mdi-arrow-left  me-1 pt-5"></i> Go Back</a>
                                         
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-xl-12">
                                 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3 ">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>

           <?php echo $__env->make('staff.staff_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<div class="card">
       <div class="card-header bg-transparent border-bottom h5  ">
                                       Add Daily Task 
                                    </div>
    <div class="card-body">

      <!-- enctype="multipart/form-data" -->
      <form action="<?php echo e(URL('/DailyReportSave')); ?>" method="post" enctype="multipart/form-data"> 

        <?php echo e(csrf_field()); ?> 


<input type="hidden" name="EmployeeID" value="<?php echo e(session::get('EmployeeID')); ?>"> 

          <div class="col-md-4 mb-3">  <label for="basicpill-firstname-input">Date</label>
            <div class="input-group" id="datepicker2">
          <input type="text" name="Date" class="form-control" placeholder="dd/mm/yyyy" data-date-format="dd/mm/yyyy" data-date-container="#datepicker2" data-provide="datepicker" data-date-autoclose="true" value="<?php echo e(date('d/m/Y')); ?>">
          <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
            </div>
          </div>

          <div class="col-md-4">
        <div class="mb-3">
        <label for="basicpill-firstname-input">Title</label>
        <input type="text" class="form-control" name="Title" required="" value="<?php echo e(old('Title')); ?>">
        </div>
        </div>
        

<div class="col-md-12">
<div class="mb-3">
<label for="verticalnav-address-input">Detail</label>
<textarea id="verticalnav-address-input" class="form-control" rows="4" name="Detail" required="" ><?php echo e(old('Title')); ?></textarea>
</div>
</div>

<div class="col-md-4">
  <div class="mb-3">
    <label for="basicpill-firstname-input">Any file/document<br></label>
    <br><input type="file" name="File" id="File" >
  </div>
</div> 
        
        


        <div><button type="submit" class="btn btn-success  btn-sm float-right">Save</button>
             
        </div>
        

      </form>

    </div>
</div>


                             <div class="card">
                                  <div class="card-header bg-transparent border-bottom h5  ">
                                        Daily Task 
                                    </div>
                                    <div class="card-body">
    
                                      

    <table class="table table-sm align-middle table-nowrap mb-0">
    <tbody><tr class="table-light">
    <th scope="col">S.No</th>
    <th scope="col">Date</th>
    <th scope="col">Title</th>
    <th scope="col">Detail</th>
    <th scope="col">File</th>
    <th scope="col">Supervisor comments</th>
    <th scope="col">Delete</th>
    </tr>
    </tbody>
    <tbody>
    <?php if(!$daily_report->isEmpty()): ?>
    <?php $__currentLoopData = $daily_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
     <td class="col-md-1"><?php echo e($key+1); ?></td>
     <td class="col-md-1"><?php echo e(dateformatman($value->Date)); ?></td>
     <td class="col-md-2"><?php echo e($value->Title); ?></td>
     <td class="col-md-1"><?php echo e($value->Detail); ?></td>
     <td class="col-md-1"><a href="<?php echo e(URL('/reports/').'/'.$value->File); ?>" target="_blank">File</a></td>
     <td class="col-md-1"><?php echo e($value->SupervisorComments); ?></td>
     <td class="col-md-1">

    <?php if($value->SupervisorComments ==null): ?>
     <a href="<?php echo e(URL('/StaffDailyReportDelete'.'/'.$value->DailyReportID)); ?>">Delete</a>
<?php endif; ?>
    </td>
     </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

       <?php else: ?>
     <tr>
       <td colspan="7" align="center" class="text-muted">Sorry no date found </td>
     </tr>  


  <?php endif; ?>


  
     </tbody>
     </table> 


 
                                    </div>
                                </div>
                                <!-- end card -->



<div class="card">
  <div class="card-header bg-transparent border-bottom h5">  Team Today Report</div>
    <div class="card-body">
    
   <table class="table table-sm align-middle table-nowrap mb-0">
    <tbody><tr class="table-light">
    <th scope="col">S.No</th>
    <th scope="col">Date</th>
    <th scope="col">Title</th>
    <th scope="col">Detail</th>
    <th scope="col">File</th>
    <th scope="col">Supervisor comments</th>
    <th scope="col">Add Comments</th>
    </tr>
    </tbody>
    <tbody>
    <?php if(!$new_daily_report->isEmpty()): ?>
    <?php $__currentLoopData = $new_daily_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
     <td class="col-md-1"><?php echo e($key+1); ?></td>
     <td class="col-md-1"><?php echo e(dateformatman($value->Date)); ?></td>
     <td class="col-md-2"><?php echo e($value->Title); ?></td>
     <td class="col-md-1"><?php echo e($value->Detail); ?></td>
     <td class="col-md-1"><a href="<?php echo e(URL('/reports/').'/'.$value->File); ?>" target="_blank">File</a></td>
     <td class="col-md-1"><?php echo e($value->SupervisorComments); ?></td>
     <td class="col-md-1">

    <?php if($value->SupervisorComments==null): ?>
     <a href="<?php echo e(URL('/StaffDailyReportEdit'.'/'.$value->DailyReportID)); ?>">Add Comments</a>
<?php endif; ?>
    </td>
     </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

       <?php else: ?>
     <tr>
       <td colspan="7" align="center" class="text-muted">Sorry no date found </td>
     </tr>  


  <?php endif; ?>


  
     </tbody>
     </table> 


    </div>
</div>



                            </div>
                            <!-- end col -->
                         
                    

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.staff_tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/staff/staff_dailyreport.blade.php ENDPATH**/ ?>
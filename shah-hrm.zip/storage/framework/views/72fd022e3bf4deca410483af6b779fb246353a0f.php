<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                Copyright &copy <?php echo e(date('Y')); ?> Extensive HR . All rights reserved
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    <!-- Design &amp; Develop by IT Department, INU -->
                                </div>
                            </div>
                        </div>
                    </div>
                </footer><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/template/footer.blade.php ENDPATH**/ ?>
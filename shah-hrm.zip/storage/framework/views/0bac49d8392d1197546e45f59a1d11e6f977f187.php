

<?php $__env->startSection('title', $pagetitle); ?>
 

<?php $__env->startSection('content'); ?>

 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Salary Section</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->
                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->


 <?php if(session('error')): ?>

<div class="alert alert-<?php echo e(Session::get('class')); ?> p-3">
                    
                  <?php echo e(Session::get('error')); ?> 
                </div>

<?php endif; ?>

  <?php if(count($errors) > 0): ?>
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                </div>

            <?php endif; ?>


                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">
                                        <!-- <h4 class="card-title mb-4"></h4> -->
                                        <form action="<?php echo e(URL('/Salary2')); ?>" method="post"> <?php echo e(csrf_field()); ?> 

                                          
                                            
                                        <div class="row">
                                                    <div class="col-md-6">
                                             <div class="mb-3">
                                                <label for="basicpill-firstname-input">Branch*</label>
                                                 <select name="BranchID" id="BranchID" class="form-select">
                                                <option value="">Select</option>
                                               <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <option value="<?php echo e($value->BranchID); ?>" <?php echo e((old('BranchID')== $value->BranchID) ? 'selected=selected': ''); ?>><?php echo e($value->BranchName); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             
                                              </select>
                                              </div>
                                               </div>
                                            
                                            
                                                 <div class="col-md-6">
                                             <div class="mb-3">
                                                <label for="basicpill-firstname-input">Month*</label>
                                                 <select name="MonthName" id="MonthName" class="form-select">
                                                <option value="">Select</option>
                                             
                                              <?php $__currentLoopData = $monthname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <option value="<?php echo e($value->MonthName); ?>" <?php echo e((old('MonthName')== $value->MonthName) ? 'selected=selected': ''); ?>><?php echo e($value->MonthName); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             
                                              </select>
                                              </div>
                                               </div>
                                            

                                                 


                                               <div><button type="submit" class="btn btn-success w-lg float-right">Save / Update</button>
                                                    <a href="<?php echo e(URL('/')); ?>" class="btn btn-secondary w-lg float-right">Cancel</a>
                                               </div>
                                               
                                            
                                        </div>
                                               

                                        </form>

                                        
                                    </div>
                                    <!-- end card body -->
                                </div>
                                <!-- end card -->
                            </div>
                            <!-- end col -->

                           
                        </div>
                        <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/salary1.blade.php ENDPATH**/ ?>
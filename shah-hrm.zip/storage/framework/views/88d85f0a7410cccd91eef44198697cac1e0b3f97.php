    <div class="col-xl-3">
    <div class="card">
    <div class="card-body p-4">

    <ul class="list-unstyled categories-list">
              <li>
                <a href="<?php echo e(URL('/EmployeeDetail')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-speedometer-slow font-size-16 text-muted me-2"></i> <span class="me-auto">Dashboard</span> 
                </a>
            </li>


            
            <li>
                <a href="<?php echo e(URL('/EmployeeDocuments')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-folder font-size-16 text-warning me-2"></i> <span class="me-auto">Documents</span> 
                </a>
            </li>
             <li>
                <a href="<?php echo e(URL('/EmployeeSalary')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-bank font-size-16 text-muted me-2"></i> <span class="me-auto">Salary</span> 
                </a>
            </li>

              <li>
                <a href="<?php echo e(URL('/EmployeeLoan')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-account-cash font-size-20 text-muted me-2"></i> <span class="me-auto">Advance / Loan</span> 
                </a>
            </li>

            <li>
                <a href="<?php echo e(URL('/EmployeeLetters')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-file-document font-size-18 me-2 text-muted "></i> <span class="me-auto">Letter</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(URL('/Leave')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-calendar-cursor
    font-size-16 me-2"></i> <span class="me-auto">Leave</span> <i class="mdi mdi-circle-medium text-danger ms-2"></i>
                </a>
            </li>
                      <li>
    <a href="<?php echo e(URL('/EmployeeLeaveReport')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-calendar-cursor
    font-size-16 me-2"></i> <span class="me-auto">Leave Report</span>  
                </a>
    </li> 
            <li>
                <a href="<?php echo e(URL('/EmployeeAttendance')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-fingerprint
    text-muted font-size-18 me-2"></i> <span class="me-auto">Attendance</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(URL('/EmployeeWarningLeter')); ?>" class="text-body d-flex align-items-center">
                    <i class="bx bxs-error-circle

    text-muted font-size-18 me-2"></i> <span class="me-auto">Warnings</span>
                </a>
            </li>
            
             <li>
                <a href="<?php echo e(URL('/EmployeeTeam')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-account-supervisor-circle
    font-size-18 text-muted me-2"></i> <span class="me-auto">Supervising</span>
                </a>
            </li>

             <li>
                <a href="<?php echo e(URL('/SalarySlip')); ?>" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-account-supervisor-circle
    font-size-18 text-muted me-2"></i> <span class="me-auto">Salary Slip</span>
                </a>
            </li>
          <!--   <li>
                <a href="javascript: void(0);" class="text-body d-flex align-items-center">
                    <i class="mdi mdi-cog text-muted font-size-16 me-2"></i> <span class="me-auto">Setting</span><span class="badge bg-success rounded-pill ms-2">01</span>
                </a>
            </li> -->
        </ul>


    <!--    <div class="search-box">
    <p class="text-muted">Search</p>
    <div class="position-relative">
    <input type="text" class="form-control rounded bg-light border-light" placeholder="Search...">
    <i class="mdi mdi-magnify search-icon"></i>
    </div>
    </div> -->

    <!--   <hr class="my-4">

    <div>
    <p class="text-muted">Categories</p>

    <ul class="list-unstyled fw-medium">
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> Design</a></li>
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> Development <span class="badge badge-soft-success rounded-pill float-end ms-1 font-size-12">04</span></a></li>
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> Business</a></li>
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> Project</a></li>
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> Travel<span class="badge badge-soft-success rounded-pill ms-1 float-end font-size-12">12</span></a></li>
    </ul>
    </div> -->

    <!--  <hr class="my-4">

    <div>
    <p class="text-muted">Archive</p>

    <ul class="list-unstyled fw-medium">
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> 2020 <span class="badge badge-soft-success rounded-pill float-end ms-1 font-size-12">03</span></a></li>
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> 2019 <span class="badge badge-soft-success rounded-pill float-end ms-1 font-size-12">06</span></a></li>
    <li><a href="#" class="text-muted py-2 d-block"><i class="mdi mdi-chevron-right me-1"></i> 2018 <span class="badge badge-soft-success rounded-pill float-end ms-1 font-size-12">05</span></a></li>
    </ul>
    </div> -->

    <!--  <hr class="my-4">

    <div>
    <p class="text-muted mb-2">Popular Posts</p>

    <div class="list-group list-group-flush">

    <a href="#" class="list-group-item text-muted py-3 px-2">
        <div class="media align-items-center">
            <div class="me-3">
                <img src="assets/images/small/img-7.jpg" alt="" class="avatar-md h-auto d-block rounded">
            </div>
            <div class="media-body overflow-hidden">
                <h5 class="font-size-13 text-truncate">Beautiful Day with Friends</h5>
                <p class="mb-0 text-truncate">10 Apr, 2020</p>
            </div>
        </div>
    </a>

    <a href="#" class="list-group-item text-muted py-3 px-2">
        <div class="media align-items-center">
            <div class="me-3">
                <img src="assets/images/small/img-4.jpg" alt="" class="avatar-md h-auto d-block rounded">
            </div>
            <div class="media-body overflow-hidden">
                <h5 class="font-size-13 text-truncate">Drawing a sketch</h5>
                <p class="mb-0 text-truncate">24 Mar, 2020</p>
            </div>
        </div>
    </a>

    <a href="#" class="list-group-item text-muted py-3 px-2">
        <div class="media align-items-center">
            <div class="me-3">
                <img src="assets/images/small/img-6.jpg" alt="" class="avatar-md h-auto d-block rounded">
            </div>
            <div class="media-body overflow-hidden">
                <h5 class="font-size-13 text-truncate">Project discussion with team</h5>
                <p class="mb-0 text-truncate">11 Mar, 2020</p>
            </div>
        </div>
    </a>
    </div>
    </div> -->

    <!-- <hr class="my-4"> -->

    <!--   <div>
    <p class="text-muted">Tags</p>

    <div class="d-flex flex-wrap gap-2 widget-tag">
    <div><a href="#" class="badge bg-light font-size-12">Design</a></div>
    <div><a href="#" class="badge bg-light font-size-12">Development</a></div>
    <div><a href="#" class="badge bg-light font-size-12">Business</a></div>
    <div><a href="#" class="badge bg-light font-size-12">Project</a></div>
    <div><a href="#" class="badge bg-light font-size-12">Travel</a></div>
    <div><a href="#" class="badge bg-light font-size-12">Lifestyle</a></div>
    <div><a href="#" class="badge bg-light font-size-12">Photography</a></div>
    </div>
    </div> -->
    </div>
    </div>
    <!-- end card -->
    </div><?php /**PATH F:\xampp88\htdocs\shah-hrm\resources\views/template/emp_sidebar.blade.php ENDPATH**/ ?>
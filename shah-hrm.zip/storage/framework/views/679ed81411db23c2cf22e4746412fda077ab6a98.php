

    <div class="col-md-4">
 <div class="mb-3">
    <label for="basicpill-firstname-input" >Select Month</label>
     <select name="MonthName" id="MonthName" class="form-select" required="">
    <option value="">Select</option>

     <?php $__currentLoopData = $MonthName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($value->MonthName); ?>"  ><?php echo e($value->MonthName); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
 </div>
  </select>
  </div>
   </div>




   

<?php /**PATH F:\xampp88\htdocs\falak_hrm\resources\views/ajax.blade.php ENDPATH**/ ?>
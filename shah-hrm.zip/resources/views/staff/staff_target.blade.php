@extends('template.staff_tmp')
@section('title', $pagetitle)
 

@section('content')
<style>
    .main-content {

    overflow: visible;
}
</style>
 <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Deals</h4>

                                    <div class="page-title-right">
                                        <div class="page-title-right">
                                         <!-- button will appear here -->

                                         

                                    </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

 @if (session('error'))

<div class="alert alert-{{ Session::get('class') }} p-3"  id="success-alert">
                    
                  <strong>{{ Session::get('error') }} </strong>
                </div>

@endif

  @if (count($errors) > 0)
                                 
                            <div >
                <div class="alert alert-danger pt-3 pl-0   border-3 bg-danger text-white">
                   <p class="font-weight-bold"> There were some problems with your input.</p>
                    <ul>
                        
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>

                        @endforeach
                    </ul>
                </div>
                </div>

            @endif

            <div class="row">
               
                
 <div class="card">
                    <div class="card-header bg-transparent border-bottom">
                          Mangae Deals
                      </div>
                      <div class="card-body">
                        
                        
                         @if($target->isNotEmpty()) 
                        <table class="table table-sm align-middle table-nowrap mb-0">
                        <tbody><tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Target Type</th>
                        <th scope="col">Name</th>
                        <th scope="col">Target Period</th>
                        <th scope="col">Detail</th>
                        
                        <th scope="col">Start Date</th>
                        <th scope="col">End Date</th>
                        
                        <th scope="col">Date</th>
                        <th scope="col">Delete</th>
                        </tr>
                        </tbody>
                        <tbody>
                        @foreach ($target as $key =>$value)

                        <?php 
                        $target_reply = DB::table('target_reply') ->get();

                         ?>

                         <tr>
                         <td class="col-md-1">{{$key+1}}</td>
                         <td class="col-md-1">{{$value->TargetType}}</td>
                         <td class="col-md-1">{{$value->TargetName}}</td>
                         <td class="col-md-1">{{$value->TargetPeriod}}</td>
                         <td class="col-md-1">{{$value->Detail}}</td>
                        
                         <td class="col-md-1">{{dateformatman($value->StartDate)}}</td>
                         <td class="col-md-1">{{dateformatman($value->EndDate)}}</td>
                         <td class="col-md-1">{{dateformatman($value->Date)}}</td>
                         
                         <td class="col-md-1"><a href="{{URL('/StaffTargetReply').'/'.$value->TargetID}}">Reply</a></td>
                         </tr>

                         @foreach($target_reply as $key2 =>$value2)


                         <tr class="bg bg-light">
                             <td colspan="1" ></td>
                             <td colspan="1" ><i class="bx bx-subdirectory-right font-size-24"></i></td>
                             
                             <td colspan="5">{{$value2->Detail}} - {{$value2->Date}}</td>
                             <td colspan="1"><a href="{{URL('/StaffTargetReplyDelete').'/'.$value2->TargetReplyID}}">Delete Reply</a></td>
                         </tr>
                         @endforeach



                         @endforeach   
                         </tbody>
                         </table>
                         @else
                           <p class=" text-danger">No data found</p>
                         @endif   


                      </div>
                  </div>
                           
            </div>
            <!-- end row -->

                      

                       

                         
                     
                        
                    </div> <!-- container-fluid -->
                </div>


  @endsection
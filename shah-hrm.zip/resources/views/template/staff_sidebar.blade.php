<div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            

                            <li>
                                <a href="{{URL('/StaffDashboard')}}" class="waves-effect">
                                    <i class="bx bx-home-circle"></i>
                                    <span key="t-dashboards">Dashboards</span>
                                </a>
                              
                            </li>

                            
                            <li>
                                <a href="{{URL('/StaffDocuments')}}" class="waves-effect">
                                    <i class="bx bx-file"></i>
                                    <span key="t-calendar">Documents</span>
                                </a>
                            </li> 
                            

                           
                               <li>
                                <a href="{{URL('/StaffSalary')}}" class="waves-effect">
                                    <i class="mdi mdi-bank"></i>
                                    <span key="t-calendar">Salary</span>
                                </a>
                            </li> 
                             

                                 <li>
                                <a href="{{URL('/StaffLetters')}}" class="waves-effect">
                                    <i class="mdi mdi-file-document"></i>
                                    <span key="t-calendar">Letter Issued</span>
                                </a>
                            </li> 


                                 <li>
                                <a href="{{URL('/StaffLeave')}}" class="waves-effect">
                                    <i class="mdi mdi-calendar-cursor"></i>
                                    <span key="t-calendar">Leave</span>
                                </a>
                            </li> 
                                

                                 <!--   <li>
                                <a href="{{URL('/StaffLeaveReport')}}" class="waves-effect">
                                    <i class="mdi mdi-calendar-cursor"></i>
                                    <span key="t-calendar">Leave Summary</span>
                                </a>
                            </li> --> 
                                
                                 <li>
                                <a href="{{URL('/StaffAttendance')}}" class="waves-effect">
                                    <i class="mdi mdi-fingerprint"></i>
                                    <span key="t-calendar">Attendance</span>
                                </a>
                            </li> 
                                 

                                  <li>
                                <a href="{{URL('/StaffTeam')}}" class="waves-effect">
                                    <i class="mdi mdi-account-supervisor-circle"></i>
                                    <span key="t-calendar">Supervising</span>
                                </a>
                            </li> 

                           

                                  <li>
                                <a href="{{URL('/StaffDailyReport')}}" class="waves-effect">
                                    <i class="bx bx-file"></i>
                                    <span key="t-calendar">Daily Report</span>
                                </a>
                            </li> 



                                  <li>
                                <a href="{{URL('/StaffLead')}}" class="waves-effect">
                                    <i class="bx bx-id-card"></i>
                                    <span key="t-calendar">Lead</span>
                                </a>
                            </li> 

                           

                                  <li>
                                <a href="{{URL('/StaffDeal')}}" class="waves-effect">
                                    <i class="mdi mdi-handshake"></i>
                                    <span key="t-calendar">Deal</span>
                                </a>
                            </li> 


                                   <li>
                                <a href="{{URL('/StaffTarget')}}" class="waves-effect">
                                    <i class="mdi mdi-target"></i>
                                    <span key="t-calendar">Target</span>
                                </a>
                            </li> 


                          <li>
                                <a href="{{URL('/StaffNoticeBoard')}}" class="waves-effect">
                                    <i class="fas fa-bullhorn font-size-16"></i>
                                    <span key="t-calendar">Notice Board</span>
                                </a>
                            </li> 

                           
                                
                              


                            


                         <!--    <li>
                                <a href="javascript: void(0);" class="has-arrow waves-effect">
                                    <i class="bx bxs-bar-chart-alt-2"></i>
                                    <span key="t-ecommerce">Reports</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    <li><a href="{{URL('/inventory')}}" key="t-products">Inventory</a></li>
                                    <li><a href="{{URL('/daily_sale')}}" key="t-products">Daily Sales</a></li>
                                    <li><a href="{{URL('/over_ledger')}}" key="t-products">Overall Ledger</a></li>
                                    <li><a href="{{URL('/rep_report')}}" key="t-products">Agent Wise Sale</a></li>
                                    <li><a href="{{URL('/daily_sale')}}" key="t-products">Month Wise Sale</a></li>
                                    <li><a href="{{ url('/export/xlsx') }}" key="t-products">Alert SMS</a></li>
                                    <li><a href="#" key="t-products">Map</a></li>
                                    <li><a href="{{URL('/daywise_payment_alert')}}" key="t-products">Day Wise Payment Alert</a></li>
                                    
                                 
                                </ul>
                            </li> -->


 <li>
                                <a href="{{URL('/logout')}}" class="waves-effect">
                                    <i class="bx bx-power-off"></i>
                                    <span key="t-calendar">Logout</span>
                                </a>
                            </li>



                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>


<center>
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="width:100%;background-color:#fcfcfc;border:1px solid #002581">
                           <tbody><tr>
                               <td valign="top">
                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <tbody><tr>
                                        <td valign="top" width="99%" align="center">
                                            <table cellspacing="0" cellpadding="0" border="0" width="99%">
                                                <tbody><tr>
                                                    <td valign="top" style="padding:10px 0;border-bottom:1px solid #ccc">
                                                        <img src="http://fcb.ae/images/logo.png" class="CToWUd">                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" style="padding:10px 0;line-height:18pt">
                                                        <div style="min-height:500px">
                                                            <p>Dear Kashif Mushtaq, </p>
<p>Thank you for expressing your interest in the Lahore University of Management Sciences (LUMS). This system generated email is to notify you, that your Online admission application account has been created with the LUMS Online Admissions successfully on December 20, 2021 8:0:4, with the following username: <a href="mailto:kashif@inu.edu.pk" target="_blank">kashif@inu.edu.pk</a>. </p>
<p>To activate the LUMS Online Admission Application account, click the following:<br>
</p>
<p><b><u>
NOTE:</u></b><br><br>
1) If you do not activate your account within the next 60 days, your account will be removed from the LUMS Online Admissions. <br>
2) Please remember your Username and Password. You will need this information to Sign in to the LUMS Online Admissions.
</p>
<p>For further queries regarding your Online account, email us at <a href="mailto:admissions@lums.edu.pk" target="_blank">admissions@lums.edu.pk</a>.<br>
</p><p>Good luck!</p>
<p>
Office of Admissions<br>
Lahore University of Management Sciences
</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr><td>&nbsp;</td></tr>
                                          </tbody></table>
                                      </td>
                                        <td valign="top" width="1%">
                                            <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tbody><tr>
                                                    <td style="background-color:#1b5f8c;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#2c8e90;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#a92a29;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#f8bd19;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#593285;height:36pt">&nbsp;</td>
                                                </tr>
                                            </tbody></table>
                                      </td>
                                    </tr>
                                </tbody></table>
                               </td>
                           </tr>
                           <tr>
                               <td valign="top" style="background-color:#00064b;margin:1px">
                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <tbody><tr><td>&nbsp;</td></tr>
                                    <tr>
                                        <td valign="top" width="100%">
                                            <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tbody><tr>
                                                    <td width="2%">&nbsp;</td>
                                                    <td width="96%">
                                                        <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tbody><tr>
                                                                <td align="center">
                                                                    <table cellspacing="0" cellpadding="0" border="0">
                                                                        <tbody><tr>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://sic.inu.edu.pk/img/facebook-50.png" alt="facebook" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://sic.inu.edu.pk/img/twitter-50.png" alt="twitter" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://sic.inu.edu.pk/img/linkedin-50.png" alt="linkedin" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://sic.inu.edu.pk/img/instagram-50.png" alt="instagram" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://sic.inu.edu.pk/img/youtube-50.png" alt="youtube" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                          <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://sic.inu.edu.pk/img/soundcloud-50.png" alt="soundcloud" class="CToWUd">                                                                            </td>
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr>
                                                                <td>
                                                                    <div style="font-size:9pt;line-height:14pt;color:#f0f0f0">
                                                                        <div>UAN: 111 11 LUMS (5867), Tel: +92 42 3560 8000, Fax: +92 42 3572 2591 - 2</div>
                                                                        <div>D.H.A, Lahore Cantt, 54792, Pakistan,</div>
                                                                        <div><a href="https://fcb.ae" style="color:#f0f0f0" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://lums.edu.pk&source=gmail&ust=1640055622806000&usg=AOvVaw0VW0zY4f1fGNDS86x3_Up7">www.fcb.ae</a></div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                    <td width="2%">&nbsp;</td>
                                                </tr>
                                            </tbody></table>
                                        </td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                </tbody></table>
                               </td>
                           </tr>
  </tbody></table>
                    </center>


 

</body>
</html>
<center>
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="width:100%;background-color:#fcfcfc;border:1px solid #002581">
                           <tbody><tr>
                               <td valign="top">
                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <tbody><tr>
                                        <td valign="top" width="99%" align="center">
                                            <table cellspacing="0" cellpadding="0" border="0" width="99%">
                                                <tbody><tr>
                                                    <td valign="top" style="padding:10px 0;border-bottom:1px solid #ccc">
                                                        <img src="http://fcb.ae/images/logo.png" class="CToWUd">                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td valign="top" style="padding:10px 0;line-height:18pt">
                                                        <div style="min-height:500px">
                                                           <p>{!!$data['Message']!!}</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr><td>&nbsp;</td></tr>
                                          </tbody></table>
                                      </td>
                                        <td valign="top" width="1%">
                                            <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tbody><tr>
                                                    <td style="background-color:#1b5f8c;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#2c8e90;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#a92a29;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#f8bd19;height:36pt">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="background-color:#593285;height:36pt">&nbsp;</td>
                                                </tr>
                                            </tbody></table>
                                      </td>
                                    </tr>
                                </tbody></table>
                               </td>
                           </tr>
                           <tr>
                               <td valign="top" style="background-color:#00064b;margin:1px">
                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                    <tbody><tr><td>&nbsp;</td></tr>
                                    <tr>
                                        <td valign="top" width="100%">
                                            <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                <tbody><tr>
                                                    <td width="2%">&nbsp;</td>
                                                    <td width="96%">
                                                        <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tbody><tr>
                                                                <td align="center">
                                                                    <table cellspacing="0" cellpadding="0" border="0">
                                                                        <tbody><tr>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://fcb.ae/img/facebook.png" alt="facebook" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://fcb.ae/img/twitter.png" alt="twitter" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://fcb.ae/img/linkedin.png" alt="linkedin" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://fcb.ae/img/instagram.png" alt="instagram" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                            <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://fcb.ae/img/youtube.png" alt="youtube" class="CToWUd">                                                                            </td>
                                                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                          <td style="width:24px;height:24px">
                                                                                  <img width="100%" src=" http://fcb.ae/img/soundcloud.png" alt="soundcloud" class="CToWUd">                                                                            </td>
                                                                        </tr>
                                                                    </tbody></table>
                                                                </td>
                                                            </tr>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr>
                                                                <td>
                                                                  <div style="font-size:9pt;line-height:14pt;color:#f0f0f0">
                                                                        <div>Tel: 0971 4717 0200, Email: <a href="mail:info@fcb.ae" style="color:#f0f0f0" target="_blank" >info@fcb.ae</a></div>
                                                                        <div>1807, Clover Bay Tower Business Bay, Dubai (UAE),</div>
                                                                        <div><a href="https://lums.edu.pk" style="color:#f0f0f0" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://fcb.ae">www.fcb.ae</a></div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                    <td width="2%">&nbsp;</td>
                                                </tr>
                                            </tbody></table>
                                        </td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                </tbody></table>
                               </td>
                           </tr>
  </tbody></table>


  
                    </center>